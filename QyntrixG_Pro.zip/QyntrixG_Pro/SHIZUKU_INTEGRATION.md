# QyntrixG Pro — Shizuku Integration Guide
## ADB Wireless Debugging Bridge · Android 8–15 · No Root

---

## What is Shizuku?

Shizuku is an Android app that allows other apps to use system APIs
with elevated privileges via ADB (Android Debug Bridge), WITHOUT
requiring root access. QyntrixG Pro uses Shizuku to execute all
network optimization commands that normally require root.

Official: https://shizuku.rikka.app

---

## Android Version Compatibility

| Android | API | Shizuku Method            | Status       |
|---------|-----|---------------------------|--------------|
| 8.0     | 26  | USB Debugging             | ✓ Supported  |
| 8.1     | 27  | USB Debugging             | ✓ Supported  |
| 9       | 28  | USB Debugging             | ✓ Supported  |
| 10      | 29  | USB Debugging             | ✓ Supported  |
| 11      | 30  | Wireless Debugging        | ✓ Best       |
| 12      | 31  | Wireless Debugging        | ✓ Best       |
| 13      | 33  | Wireless Debugging        | ✓ Best       |
| 14      | 34  | Wireless Debugging        | ✓ Recommended|
| 15      | 35  | Wireless Debugging        | ✓ Recommended|

---

## Commands Executed via Shizuku

### System Optimization
```
settings put global low_latency_mode 1
settings put global wifi_sleep_policy 2
```

### Kernel Network Tuning
```
sysctl -w net.ipv4.tcp_fastopen=3
sysctl -w net.core.rmem_max=16777216
sysctl -w net.ipv4.tcp_no_metrics_save=1
```

### Traffic Control (HTB)
```
tc qdisc add dev wlan0 root handle 1: htb default 10
tc class add dev wlan0 parent 1: classid 1:10 htb rate 100mbit ceil 100mbit
tc filter add dev wlan0 parent 1: protocol ip u32 match ip dsfield 0xb8 0xfc flowid 1:10
```

### iptables Game Packet Prioritization
```
iptables -t mangle -A OUTPUT -p udp --dport 10012 -j DSCP --set-dscp-class EF
iptables -A OUTPUT -p udp -m multiport --dports 10012,17000,17500 -j MARK --set-mark 1
iptables -t mangle -A PREROUTING -p udp -m dscp --dscp-class EF -j ACCEPT
```

### IP Routing
```
ip rule add fwmark 1 table 100 pref 1000
ip route add 103.28.54.0/24 dev wlan0 metric 1 table 100
```

---

## Shizuku API Integration (Native Android / Java)

### 1. Add dependency to build.gradle

```gradle
dependencies {
    implementation 'dev.rikka.shizuku:api:13.1.5'
    implementation 'dev.rikka.shizuku:provider:13.1.5'
}
```

### 2. Add to AndroidManifest.xml

```xml
<uses-permission android:name="moe.shizuku.manager.permission.API_V23"/>

<provider
    android:name="rikka.shizuku.ShizukuProvider"
    android:authorities="${applicationId}.shizuku"
    android:multiprocess="false"
    android:enabled="true"
    android:exported="true"
    android:permission="android.permission.INTERACT_ACROSS_USERS_FULL" />
```

### 3. Check and Request Permission

```kotlin
private fun checkShizukuPermission(): Boolean {
    if (Shizuku.isPreV11()) return false
    return if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
        true
    } else if (Shizuku.shouldShowRequestPermissionRationale()) {
        false
    } else {
        Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        false
    }
}
```

### 4. Execute Commands via Shizuku

```kotlin
fun executeShizukuCommand(command: String): String {
    if (!checkShizukuPermission()) return "Permission denied"
    
    val process = Shizuku.newProcess(
        arrayOf("sh", "-c", command),
        null,
        null
    )
    
    val output = process.inputStream.bufferedReader().readText()
    process.waitFor()
    return output.trim()
}
```

### 5. Execute All QyntrixG Commands

```kotlin
fun applyQyntrixGOptimization() {
    val commands = listOf(
        "settings put global low_latency_mode 1",
        "settings put global wifi_sleep_policy 2",
        "sysctl -w net.ipv4.tcp_fastopen=3",
        "sysctl -w net.core.rmem_max=16777216",
        "tc qdisc add dev wlan0 root handle 1: htb default 10",
        "tc class add dev wlan0 parent 1: classid 1:10 htb rate 100mbit ceil 100mbit",
        "iptables -t mangle -A OUTPUT -p udp --dport 10012 -j DSCP --set-dscp-class EF",
        "ip rule add fwmark 1 table 100 pref 1000"
    )
    
    commands.forEach { cmd ->
        val result = executeShizukuCommand(cmd)
        Log.d("QyntrixG", "CMD: $cmd | Result: $result")
    }
}
```

### 6. Foreground Service (Background Persistence)

```kotlin
class QyntrixGService : Service() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("QyntrixG Pro · Optimizing")
            .setContentText("Ping: 12ms · Alpha-01 · Tokyo")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .build()
        
        startForeground(1, notification)
        return START_STICKY
    }
}
```

---

## React Native / Expo Native Module (Bridge)

To call Kotlin from React Native JS, create a native module:

```kotlin
// QyntrixGModule.kt
class QyntrixGModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName() = "QyntrixGShizuku"

    @ReactMethod
    fun executeCommand(command: String, promise: Promise) {
        try {
            val result = executeShizukuCommand(command)
            promise.resolve(result)
        } catch (e: Exception) {
            promise.reject("SHIZUKU_ERROR", e.message)
        }
    }
}
```

```typescript
// In React Native (JS/TS)
import { NativeModules } from 'react-native';
const { QyntrixGShizuku } = NativeModules;

async function runShizukuCommand(cmd: string): Promise<string> {
  return await QyntrixGShizuku.executeCommand(cmd);
}
```

---

## Wireless Debugging Setup (Android 11+)

1. Settings → About Phone → tap Build Number 7 times
2. Settings → Developer Options → enable Developer Options
3. Developer Options → Wireless Debugging → enable
4. Tap "Pair device with pairing code"
5. Note the IP, port, and pairing code
6. In terminal: `adb pair <ip>:<port> <code>`
7. Then: `adb connect <ip>:5555`
8. Open Shizuku → "Start via Wireless Debugging"
