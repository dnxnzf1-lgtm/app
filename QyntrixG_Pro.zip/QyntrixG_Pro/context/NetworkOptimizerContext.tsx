import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { Game } from "@/data/games";

export type NetworkPath = {
  id: number;
  name: string;
  region: string;
  latency: number;
  packetLoss: number;
  jitter: number;
  status: "optimal" | "good" | "degraded" | "offline";
};

export type DnsServer = {
  id: string;
  name: string;
  address: string;
  latency: number;
  doh: boolean;
  active: boolean;
};

export type RecoveryEvent = {
  id: number;
  path: string;
  timeMs: number;
  recoveredIn: string;
};

export type LoadBalanceEntry = {
  pathId: number;
  name: string;
  percent: number;
};

type ConnectionQuality = "excellent" | "good" | "fair" | "poor";

type NetworkState = {
  isOptimizing: boolean;
  aiEnabled: boolean;
  currentPathId: number;
  currentDnsId: string;
  paths: NetworkPath[];
  dnsServers: DnsServer[];
  ping: number;
  packetLoss: number;
  jitter: number;
  downloadSpeed: number;
  uploadSpeed: number;
  connectionQuality: ConnectionQuality;
  aiLog: string[];
  optimizationLevel: number;
  shizukuGranted: boolean;
  pingHistory: number[];
  gameSensing: boolean;
  packetReorder: boolean;
  dualChannel: boolean;
  tunnelingProtocol: string;
  // Game engine
  activeGame: Game | null;
  packetRecoveryCount: number;
  recoveryEvents: RecoveryEvent[];
  ioSyncDelta: number;
  inputLatency: number;
  serverResponse: number;
  loadBalance: LoadBalanceEntry[];
  startOptimizing: () => void;
  stopOptimizing: () => void;
  switchPath: (id: number) => void;
  switchDns: (id: string) => void;
  toggleAi: () => void;
  setOptimizationLevel: (level: number) => void;
  setGameSensing: (v: boolean) => void;
  setPacketReorder: (v: boolean) => void;
  setDualChannel: (v: boolean) => void;
  setTunnelingProtocol: (p: string) => void;
  setActiveGame: (game: Game | null) => void;
};

const BASE_PATHS: Omit<NetworkPath, "latency" | "packetLoss" | "jitter" | "status">[] = [
  { id: 1, name: "Alpha-01", region: "Tokyo, JP" },
  { id: 2, name: "Alpha-02", region: "Seoul, KR" },
  { id: 3, name: "Alpha-03", region: "Singapore, SG" },
  { id: 4, name: "Alpha-04", region: "Hong Kong, HK" },
  { id: 5, name: "Beta-05", region: "Los Angeles, US" },
  { id: 6, name: "Beta-06", region: "New York, US" },
  { id: 7, name: "Beta-07", region: "Toronto, CA" },
  { id: 8, name: "Gamma-08", region: "London, UK" },
  { id: 9, name: "Gamma-09", region: "Frankfurt, DE" },
  { id: 10, name: "Gamma-10", region: "Amsterdam, NL" },
  { id: 11, name: "Delta-11", region: "Mumbai, IN" },
  { id: 12, name: "Delta-12", region: "Dubai, UAE" },
  { id: 13, name: "Delta-13", region: "Cairo, EG" },
  { id: 14, name: "Omega-14", region: "Sydney, AU" },
  { id: 15, name: "Omega-15", region: "São Paulo, BR" },
];

const BASE_LATENCIES = [12, 15, 18, 21, 45, 52, 61, 89, 95, 91, 68, 74, 112, 142, 198];

const BASE_DNS: Omit<DnsServer, "latency" | "active">[] = [
  { id: "cloudflare", name: "Cloudflare", address: "1.1.1.1", doh: true },
  { id: "google", name: "Google DNS", address: "8.8.8.8", doh: true },
  { id: "quad9", name: "Quad9", address: "9.9.9.9", doh: true },
  { id: "opendns", name: "OpenDNS", address: "208.67.222.222", doh: false },
  { id: "nextdns", name: "NextDNS", address: "45.90.28.0", doh: true },
];

const DNS_BASE_LAT: Record<string, number> = {
  cloudflare: 8, google: 12, quad9: 22, opendns: 18, nextdns: 15,
};

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getStatus(latency: number): NetworkPath["status"] {
  if (latency < 30) return "optimal";
  if (latency < 60) return "good";
  if (latency < 120) return "degraded";
  return "offline";
}

function getQuality(ping: number, pl: number): ConnectionQuality {
  if (ping < 25 && pl < 0.5) return "excellent";
  if (ping < 50 && pl < 1) return "good";
  if (ping < 100 && pl < 3) return "fair";
  return "poor";
}

function buildPaths(): NetworkPath[] {
  return BASE_PATHS.map((p, i) => {
    const latency = BASE_LATENCIES[i] + rand(-3, 8);
    const packetLoss = parseFloat((Math.random() * 1.5).toFixed(2));
    const jitter = rand(1, Math.max(2, Math.floor(latency / 6)));
    return { ...p, latency, packetLoss, jitter, status: getStatus(latency) };
  });
}

function buildDns(): DnsServer[] {
  return BASE_DNS.map((d) => ({
    ...d,
    latency: DNS_BASE_LAT[d.id] + rand(-2, 5),
    active: d.id === "cloudflare",
  }));
}

function buildLoadBalance(paths: NetworkPath[]): LoadBalanceEntry[] {
  const optimal = paths.filter((p) => p.latency < 100);
  const total = optimal.length || 1;
  const weights = optimal.map((p) => 1 / Math.max(1, p.latency));
  const sumW = weights.reduce((a, b) => a + b, 0);
  return optimal.map((p, i) => ({
    pathId: p.id,
    name: p.name,
    percent: Math.round((weights[i] / sumW) * 100),
  })).sort((a, b) => b.percent - a.percent);
}

const PING_HISTORY_SIZE = 50;
let recoveryIdCounter = 0;

const NetworkOptimizerContext = createContext<NetworkState | null>(null);

export function NetworkOptimizerProvider({ children }: { children: React.ReactNode }) {
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(true);
  const [currentPathId, setCurrentPathId] = useState(1);
  const [currentDnsId, setCurrentDnsId] = useState("cloudflare");
  const [paths, setPaths] = useState<NetworkPath[]>(buildPaths);
  const [dnsServers, setDnsServers] = useState<DnsServer[]>(buildDns);
  const [ping, setPing] = useState(12);
  const [packetLoss, setPacketLoss] = useState(0);
  const [jitter, setJitter] = useState(2);
  const [downloadSpeed, setDownloadSpeed] = useState(94.2);
  const [uploadSpeed, setUploadSpeed] = useState(48.6);
  const [connectionQuality, setConnectionQuality] = useState<ConnectionQuality>("excellent");
  const [aiLog, setAiLog] = useState<string[]>([]);
  const [optimizationLevel, setOptimizationLevelState] = useState(3);
  const [shizukuGranted] = useState(true);
  const [pingHistory, setPingHistory] = useState<number[]>(() =>
    Array.from({ length: 20 }, () => 12 + rand(-2, 5))
  );
  const [gameSensing, setGameSensing] = useState(false);
  const [packetReorder, setPacketReorder] = useState(false);
  const [dualChannel, setDualChannel] = useState(false);
  const [tunnelingProtocol, setTunnelingProtocol] = useState("direct");

  // Game engine state
  const [activeGame, setActiveGameState] = useState<Game | null>(null);
  const [packetRecoveryCount, setPacketRecoveryCount] = useState(0);
  const [recoveryEvents, setRecoveryEvents] = useState<RecoveryEvent[]>([]);
  const [ioSyncDelta, setIoSyncDelta] = useState(1.4);
  const [inputLatency, setInputLatency] = useState(8.2);
  const [serverResponse, setServerResponse] = useState(9.6);
  const [loadBalance, setLoadBalance] = useState<LoadBalanceEntry[]>([]);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recoveryIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const ioIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const addLog = useCallback((msg: string) => {
    const now = new Date();
    const time = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`;
    setAiLog((prev) => [`[${time}] ${msg}`, ...prev].slice(0, 30));
  }, []);

  const simulate = useCallback(() => {
    setPaths((prev) => {
      const updated = prev.map((p, i) => {
        const latency = Math.max(8, BASE_LATENCIES[i] + rand(-5, 12));
        const packetLoss = parseFloat((Math.random() * 2).toFixed(2));
        const jitter = rand(1, Math.max(2, Math.floor(latency / 6)));
        return { ...p, latency, packetLoss, jitter, status: getStatus(latency) };
      });
      setLoadBalance(buildLoadBalance(updated));
      return updated;
    });

    setDnsServers((prev) =>
      prev.map((d) => ({ ...d, latency: Math.max(3, DNS_BASE_LAT[d.id] + rand(-2, 6)) }))
    );

    setPaths((currentPaths) => {
      const current = currentPaths.find((p) => p.id === currentPathId);
      if (!current) return currentPaths;

      const basePing = current.latency;
      const noise = (Math.random() - 0.3) * 4;
      const newPing = Math.max(5, Math.round(basePing + noise));
      const newPl = parseFloat((Math.random() * 1.2).toFixed(2));
      const newJitter = Math.max(1, rand(1, Math.max(2, Math.floor(basePing / 5))));

      setPing(newPing);
      setPacketLoss(newPl);
      setJitter(newJitter);
      setDownloadSpeed(parseFloat((rand(60, 120) + Math.random()).toFixed(1)));
      setUploadSpeed(parseFloat((rand(30, 60) + Math.random()).toFixed(1)));
      setConnectionQuality(getQuality(newPing, newPl));
      setPingHistory((prev) => {
        const next = [...prev, newPing];
        return next.length > PING_HISTORY_SIZE ? next.slice(-PING_HISTORY_SIZE) : next;
      });

      if (aiEnabled && newPing > 40) {
        const better = currentPaths
          .filter((p) => p.id !== currentPathId && p.latency < current.latency && p.jitter < 4)
          .sort((a, b) => a.latency - b.latency)[0];
        if (better) {
          setCurrentPathId(better.id);
          addLog(`AI → ${better.name} (${better.region}) ${better.latency}ms ↓ jitter:${better.jitter}ms`);
        }
      }

      return currentPaths;
    });
  }, [currentPathId, aiEnabled, addLog]);

  // I/O sync simulation
  const simulateIoSync = useCallback(() => {
    const input = 6 + Math.random() * 6;
    const server = input + Math.random() * 3;
    const delta = Math.abs(server - input);
    setInputLatency(parseFloat(input.toFixed(1)));
    setServerResponse(parseFloat(server.toFixed(1)));
    setIoSyncDelta(parseFloat(delta.toFixed(1)));
  }, []);

  // Packet recovery simulation
  const simulatePacketRecovery = useCallback(() => {
    setPaths((currentPaths) => {
      const alternatives = currentPaths
        .filter((p) => p.id !== currentPathId && p.latency < 80)
        .sort((a, b) => a.latency - b.latency);
      if (alternatives.length === 0) return currentPaths;
      const via = alternatives[0];
      const recoverMs = parseFloat((0.08 + Math.random() * 0.04).toFixed(2));
      const event: RecoveryEvent = {
        id: ++recoveryIdCounter,
        path: via.name,
        timeMs: Date.now(),
        recoveredIn: `${recoverMs}ms`,
      };
      setPacketRecoveryCount((n) => n + 1);
      setRecoveryEvents((prev) => [event, ...prev].slice(0, 10));
      addLog(`⚡ Fast-Retransmit: dropped pkt → injected via ${via.name} in ${recoverMs}ms`);
      return currentPaths;
    });
  }, [currentPathId, addLog]);

  useEffect(() => {
    if (isOptimizing) {
      addLog("Engine started — monitoring 15 paths");
      intervalRef.current = setInterval(simulate, 2000);
      ioIntervalRef.current = setInterval(simulateIoSync, 2200);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (ioIntervalRef.current) clearInterval(ioIntervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (ioIntervalRef.current) clearInterval(ioIntervalRef.current);
    };
  }, [isOptimizing, simulate, simulateIoSync, addLog]);

  // Packet recovery fires randomly when game is active + optimizing
  useEffect(() => {
    if (isOptimizing && activeGame) {
      const scheduleNext = () => {
        const delay = rand(7000, 16000);
        recoveryIntervalRef.current = setTimeout(() => {
          simulatePacketRecovery();
          scheduleNext();
        }, delay);
      };
      scheduleNext();
      return () => { if (recoveryIntervalRef.current) clearTimeout(recoveryIntervalRef.current); };
    }
  }, [isOptimizing, activeGame, simulatePacketRecovery]);

  useEffect(() => {
    AsyncStorage.getItem("qyntrix_settings").then((val) => {
      if (!val) return;
      try {
        const s = JSON.parse(val);
        if (s.optimizationLevel) setOptimizationLevelState(s.optimizationLevel);
        if (s.aiEnabled !== undefined) setAiEnabled(s.aiEnabled);
        if (s.tunnelingProtocol) setTunnelingProtocol(s.tunnelingProtocol);
        if (s.packetReorder !== undefined) setPacketReorder(s.packetReorder);
        if (s.dualChannel !== undefined) setDualChannel(s.dualChannel);
      } catch {}
    });
    setLoadBalance(buildLoadBalance(buildPaths()));
  }, []);

  const saveSettings = useCallback(
    (overrides: object) => {
      AsyncStorage.setItem(
        "qyntrix_settings",
        JSON.stringify({ optimizationLevel, aiEnabled, tunnelingProtocol, packetReorder, dualChannel, ...overrides })
      );
    },
    [optimizationLevel, aiEnabled, tunnelingProtocol, packetReorder, dualChannel]
  );

  const startOptimizing = useCallback(() => {
    setIsOptimizing(true);
    addLog("Initializing QyntrixG engine...");
  }, [addLog]);

  const stopOptimizing = useCallback(() => {
    setIsOptimizing(false);
    addLog("Optimization stopped");
  }, [addLog]);

  const switchPath = useCallback((id: number) => {
    setCurrentPathId(id);
    setPaths((prev) => {
      const p = prev.find((x) => x.id === id);
      if (p) addLog(`Manual → ${p.name} (${p.region}) ${p.latency}ms`);
      return prev;
    });
  }, [addLog]);

  const switchDns = useCallback((id: string) => {
    setCurrentDnsId(id);
    setDnsServers((prev) => prev.map((d) => ({ ...d, active: d.id === id })));
    const d = BASE_DNS.find((x) => x.id === id);
    if (d) addLog(`DNS → ${d.name} (${d.address})`);
  }, [addLog]);

  const toggleAi = useCallback(() => {
    setAiEnabled((prev) => {
      saveSettings({ aiEnabled: !prev });
      addLog(!prev ? "AI path-switching enabled" : "AI path-switching disabled");
      return !prev;
    });
  }, [saveSettings, addLog]);

  const setOptimizationLevel = useCallback((level: number) => {
    setOptimizationLevelState(level);
    saveSettings({ optimizationLevel: level });
    addLog(`Optimization level → ${level}/5`);
  }, [saveSettings, addLog]);

  const handleSetTunnelingProtocol = useCallback((p: string) => {
    setTunnelingProtocol(p);
    saveSettings({ tunnelingProtocol: p });
    addLog(`Tunneling protocol → ${p}`);
  }, [saveSettings, addLog]);

  const handleSetPacketReorder = useCallback((v: boolean) => {
    setPacketReorder(v);
    saveSettings({ packetReorder: v });
    addLog(v ? "Packet re-ordering prevention: ON" : "Packet re-ordering prevention: OFF");
  }, [saveSettings, addLog]);

  const handleSetDualChannel = useCallback((v: boolean) => {
    setDualChannel(v);
    saveSettings({ dualChannel: v });
    addLog(v ? "Dual-channel bridge: ACTIVE" : "Dual-channel bridge: OFF");
  }, [saveSettings, addLog]);

  const handleSetGameSensing = useCallback((v: boolean) => {
    setGameSensing(v);
    addLog(v ? "Game sensing: ON — Ghost Mode enabled" : "Game sensing: OFF");
  }, [addLog]);

  const setActiveGame = useCallback((game: Game | null) => {
    setActiveGameState(game);
    if (game) {
      setPacketRecoveryCount(0);
      setRecoveryEvents([]);
      addLog(`🎮 ${game.name} detected — activating port bridge`);
      addLog(`📡 Forwarding ports: UDP ${game.udpPorts.slice(0, 3).join(", ")}${game.tcpPorts.length ? ` · TCP ${game.tcpPorts[0]}` : ""}`);
      addLog(`🔒 IP ranges locked: ${game.serverRanges[0]}`);
      setPaths((currentPaths) => {
        setLoadBalance(buildLoadBalance(currentPaths));
        return currentPaths;
      });
    } else {
      addLog("🎮 Game session ended — port bridge deactivated");
    }
  }, [addLog]);

  return (
    <NetworkOptimizerContext.Provider
      value={{
        isOptimizing, aiEnabled, currentPathId, currentDnsId,
        paths, dnsServers, ping, packetLoss, jitter,
        downloadSpeed, uploadSpeed, connectionQuality,
        aiLog, optimizationLevel, shizukuGranted,
        pingHistory, gameSensing, packetReorder, dualChannel, tunnelingProtocol,
        activeGame, packetRecoveryCount, recoveryEvents,
        ioSyncDelta, inputLatency, serverResponse, loadBalance,
        startOptimizing, stopOptimizing,
        switchPath, switchDns, toggleAi, setOptimizationLevel,
        setGameSensing: handleSetGameSensing,
        setPacketReorder: handleSetPacketReorder,
        setDualChannel: handleSetDualChannel,
        setTunnelingProtocol: handleSetTunnelingProtocol,
        setActiveGame,
      }}
    >
      {children}
    </NetworkOptimizerContext.Provider>
  );
}

export function useNetworkOptimizer() {
  const ctx = useContext(NetworkOptimizerContext);
  if (!ctx) throw new Error("useNetworkOptimizer must be used within NetworkOptimizerProvider");
  return ctx;
}
