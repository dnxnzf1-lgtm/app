# QyntrixG Pro — Build Instructions
## Android 8–15 · Shizuku-Only · No Root Required

---

## OPTION A — EAS Build (Recommended, Easiest)

### Prerequisites
- Node.js 18+
- pnpm or npm
- Expo CLI: `npm install -g eas-cli`
- Expo account: https://expo.dev

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Login to Expo
eas login

# 3. Configure EAS (first time only)
eas build:configure

# 4. Build Android APK (development)
eas build --platform android --profile development

# 5. Build Android APK (production, signed)
eas build --platform android --profile production
```

The APK/AAB download link will appear in your Expo dashboard
at https://expo.dev — takes 5–10 minutes.

---

## OPTION B — Android Studio Local Build

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 26–35
- Java JDK 17
- Node.js 18+

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Generate native Android project
npx expo prebuild --platform android --clean

# 3. Open in Android Studio
# File → Open → select the `android/` folder

# 4. Build → Generate Signed Bundle/APK
# Select APK → create/use your keystore → build
```

### Gradle Configuration
After prebuild, the `android/` folder is generated with:
- `app/build.gradle` — min SDK 26, target SDK 35
- `app/src/main/AndroidManifest.xml` — all permissions set
- `settings.gradle` — project configuration

---

## OPTION C — Direct ADB Sideload (Debug Build)

```bash
# 1. Enable Developer Options on Android device
# 2. Enable USB Debugging
# 3. Connect device via USB

npm install
npx expo prebuild --platform android
cd android
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Shizuku Setup (After Install)

1. Download Shizuku from Google Play
2. Enable Wireless Debugging (Android 11+) or USB Debugging (Android 8–10)
3. Open Shizuku → tap "Start via Wireless Debugging" (or USB)
4. Open QyntrixG Pro
5. Go to Settings → Shizuku Terminal → tap EXECUTE
6. Shizuku permission dialog will appear → tap Allow

See SHIZUKU_INTEGRATION.md for full technical details.
