import React, { useEffect, useRef, useState } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import DataFlowBackground from "@/components/DataFlowBackground";
import GlitchText from "@/components/GlitchText";
import NetworkMeshLoader from "@/components/NetworkMeshLoader";
import { useLang } from "@/context/LanguageContext";

type Phase = 0 | 1 | 2 | 3;

const BLUE = "#00d4ff";
const VIOLET = "#8b5cf6";

export default function SplashScreen() {
  const { t } = useLang();
  const [phase, setPhase] = useState<Phase>(0);

  const brandOpacity = useRef(new Animated.Value(0)).current;
  const bgOpacity = useRef(new Animated.Value(0)).current;
  const greetingOpacity = useRef(new Animated.Value(0)).current;
  const greetingScale = useRef(new Animated.Value(0.9)).current;
  const meshOpacity = useRef(new Animated.Value(0)).current;
  const screenFade = useRef(new Animated.Value(1)).current;
  const screenScale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // Phase 0→1: Brand reveal
    Animated.parallel([
      Animated.timing(brandOpacity, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.timing(bgOpacity, { toValue: 1, duration: 1000, useNativeDriver: true }),
    ]).start();

    // Phase 1→2: Greeting
    const t1 = setTimeout(() => {
      setPhase(1);
      Animated.parallel([
        Animated.timing(brandOpacity, { toValue: 0, duration: 500, useNativeDriver: true }),
        Animated.timing(bgOpacity, { toValue: 0.3, duration: 500, useNativeDriver: true }),
      ]).start(() => {
        setPhase(2);
        Animated.parallel([
          Animated.timing(greetingOpacity, { toValue: 1, duration: 600, useNativeDriver: true }),
          Animated.spring(greetingScale, { toValue: 1, useNativeDriver: true, tension: 80 }),
        ]).start();
      });
    }, 2800);

    // Phase 2→3: Network mesh loader
    const t2 = setTimeout(() => {
      Animated.parallel([
        Animated.timing(greetingOpacity, { toValue: 0, duration: 400, useNativeDriver: true }),
      ]).start(() => {
        setPhase(3);
        Animated.timing(meshOpacity, { toValue: 1, duration: 500, useNativeDriver: true }).start();
      });
    }, 4600);

    // Navigate to dashboard
    const t3 = setTimeout(() => {
      Animated.parallel([
        Animated.timing(screenFade, { toValue: 0, duration: 500, useNativeDriver: true }),
        Animated.timing(screenScale, { toValue: 1.12, duration: 500, useNativeDriver: true }),
      ]).start(() => router.replace("/(tabs)"));
    }, 6200);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [brandOpacity, bgOpacity, greetingOpacity, greetingScale, meshOpacity, screenFade, screenScale]);

  return (
    <Animated.View
      style={[styles.root, { opacity: screenFade, transform: [{ scale: screenScale }] }]}
    >
      {/* Data paths background */}
      <Animated.View style={[StyleSheet.absoluteFill, { opacity: bgOpacity }]}>
        <DataFlowBackground lineCount={24} />
      </Animated.View>

      {/* Subtle grid */}
      <View style={styles.grid} pointerEvents="none">
        {Array.from({ length: 10 }, (_, i) => (
          <View
            key={`h${i}`}
            style={[styles.gridH, { top: `${i * 10}%` as unknown as number }]}
          />
        ))}
        {Array.from({ length: 7 }, (_, i) => (
          <View
            key={`v${i}`}
            style={[styles.gridV, { left: `${i * 16.6}%` as unknown as number }]}
          />
        ))}
      </View>

      {/* Corner decorations */}
      <CornerDec pos="TL" />
      <CornerDec pos="TR" />
      <CornerDec pos="BL" />
      <CornerDec pos="BR" />

      {/* Phase 1: Brand */}
      <Animated.View style={[styles.center, { opacity: brandOpacity }]}>
        <Text style={styles.versionBadge}>{t.splashVersion}</Text>
        <GlitchText text="QyntrixG" fontSize={54} />
        <Text style={styles.tagline}>ULTIMATE NETWORK OPTIMIZER</Text>
        <View style={styles.divider} />
        <Text style={styles.subTagline}>{t.splashSub}</Text>
      </Animated.View>

      {/* Phase 2: Arabic greeting */}
      <Animated.View
        style={[
          styles.center,
          styles.absolute,
          { opacity: greetingOpacity, transform: [{ scale: greetingScale }] },
        ]}
      >
        <View style={styles.greetingCard}>
          <View style={[styles.greetingTopBar, { backgroundColor: BLUE }]} />
          <Text style={styles.greetingAr}>{t.splashGreeting}</Text>
          {t.splashGreetingAr ? (
            <Text style={styles.greetingEn}>{t.splashGreetingAr}</Text>
          ) : (
            <Text style={styles.greetingEn}>Welcome to the Gamers Republic</Text>
          )}
          <View style={styles.greetingDivider} />
          <View style={styles.greetingRow}>
            <View style={[styles.greetingDot, { backgroundColor: "#00ff88" }]} />
            <Text style={styles.greetingStatus}>{t.splashInit}</Text>
          </View>
        </View>
      </Animated.View>

      {/* Phase 3: Network mesh loader */}
      <Animated.View style={[styles.center, styles.absolute, { opacity: meshOpacity }]}>
        <NetworkMeshLoader label="AI NETWORK SCAN" />
        <Text style={styles.scanSub}>{t.splashScanSub}</Text>
        <ScanBar />
      </Animated.View>

      {/* Bottom brand */}
      <View style={styles.bottomBrand}>
        <Text style={styles.bottomText}>{t.splashBrand}</Text>
      </View>
    </Animated.View>
  );
}

function ScanBar() {
  const prog = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    setTimeout(() => {
      Animated.timing(prog, { toValue: 1, duration: 1600, useNativeDriver: false }).start();
    }, 300);
  }, [prog]);
  const w = prog.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });
  return (
    <View style={scanStyles.track}>
      <Animated.View style={[scanStyles.fill, { width: w }]} />
    </View>
  );
}
const scanStyles = StyleSheet.create({
  track: { width: 200, height: 3, backgroundColor: "#1a2f50", borderRadius: 2, overflow: "hidden", marginTop: 24 },
  fill: { height: "100%", backgroundColor: "#00d4ff", borderRadius: 2, shadowColor: "#00d4ff", shadowOffset: { width: 0, height: 0 }, shadowRadius: 6, shadowOpacity: 1 },
});

function CornerDec({ pos }: { pos: "TL" | "TR" | "BL" | "BR" }) {
  const isT = pos.startsWith("T");
  const isL = pos.endsWith("L");
  return (
    <View
      style={[
        styles.corner,
        isT ? { top: 58 } : { bottom: 58 },
        isL ? { left: 20 } : { right: 20 },
        {
          borderTopWidth: isT ? 2 : 0,
          borderBottomWidth: !isT ? 2 : 0,
          borderLeftWidth: isL ? 2 : 0,
          borderRightWidth: !isL ? 2 : 0,
        },
      ]}
    />
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#05070f", alignItems: "center", justifyContent: "center" },
  center: { alignItems: "center", justifyContent: "center", paddingHorizontal: 24 },
  absolute: { position: "absolute", left: 0, right: 0, top: 0, bottom: 0 },
  grid: { ...StyleSheet.absoluteFillObject, opacity: 0.03 },
  gridH: { position: "absolute", left: 0, right: 0, height: 1, backgroundColor: BLUE },
  gridV: { position: "absolute", top: 0, bottom: 0, width: 1, backgroundColor: BLUE },
  corner: { position: "absolute", width: 22, height: 22, borderColor: `${BLUE}70` },
  versionBadge: {
    color: VIOLET, fontSize: 10, fontWeight: "700", letterSpacing: 4,
    marginBottom: 18, textTransform: "uppercase", borderWidth: 1,
    borderColor: `${VIOLET}55`, paddingHorizontal: 12, paddingVertical: 4, borderRadius: 4,
  },
  tagline: { color: "#4b6280", fontSize: 10, fontWeight: "600", letterSpacing: 3, marginTop: 16, textTransform: "uppercase" },
  divider: { width: 60, height: 1, backgroundColor: BLUE, marginVertical: 12, opacity: 0.4 },
  subTagline: { color: `${BLUE}aa`, fontSize: 11, letterSpacing: 2, fontWeight: "500" },
  greetingCard: {
    backgroundColor: "#0a1020", borderWidth: 1, borderColor: `${BLUE}30`,
    borderRadius: 16, padding: 24, alignItems: "center", gap: 10, overflow: "hidden", width: "100%",
  },
  greetingTopBar: { position: "absolute", top: 0, left: 0, right: 0, height: 2, opacity: 0.7 },
  greetingAr: { color: "#e8f4ff", fontSize: 26, fontWeight: "700", textAlign: "center", letterSpacing: 0.5 },
  greetingEn: { color: `${BLUE}cc`, fontSize: 14, fontWeight: "600", letterSpacing: 2, textTransform: "uppercase" },
  greetingDivider: { width: 80, height: 1, backgroundColor: BLUE, opacity: 0.3 },
  greetingRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  greetingDot: { width: 6, height: 6, borderRadius: 3 },
  greetingStatus: { color: "#4b6280", fontSize: 11, letterSpacing: 1.5 },
  scanSub: { color: "#4b6280", fontSize: 10, letterSpacing: 1.5, marginTop: 16, textTransform: "uppercase" },
  bottomBrand: { position: "absolute", bottom: 40 },
  bottomText: { color: "#1e3a5f", fontSize: 9, letterSpacing: 2, fontWeight: "600" },
});
