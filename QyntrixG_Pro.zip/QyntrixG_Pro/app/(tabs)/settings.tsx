import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import { Platform, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import AndroidGuideModal from "@/components/AndroidGuideModal";
import ShizukuTerminal from "@/components/ShizukuTerminal";
import { useLang } from "@/context/LanguageContext";
import { useNetworkOptimizer } from "@/context/NetworkOptimizerContext";
import { useColors } from "@/hooks/useColors";

const OPTIMIZATION_LEVELS = ["Off", "Eco", "Balanced", "Boost", "Ultra", "MAX"];

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <View style={sect.wrapper}>
      <Text style={[sect.title, { color: colors.mutedForeground }]}>{title}</Text>
      <View style={[sect.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {children}
      </View>
    </View>
  );
}
const sect = StyleSheet.create({
  wrapper: { gap: 6 },
  title: { fontSize: 9, fontWeight: "700", letterSpacing: 3, textTransform: "uppercase", paddingHorizontal: 4 },
  card: { borderRadius: 12, borderWidth: 1, overflow: "hidden" },
});

function Row({
  icon, iconColor, label, value, onPress, toggle, toggleValue, onToggle, last, isRTL,
}: {
  icon: string; iconColor: string; label: string; value?: string;
  onPress?: () => void; toggle?: boolean; toggleValue?: boolean;
  onToggle?: (v: boolean) => void; last?: boolean; isRTL?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      style={[
        row.wrap,
        !last && { borderBottomWidth: 1, borderBottomColor: colors.border },
        isRTL && { flexDirection: "row-reverse" },
      ]}
      onPress={onPress}
    >
      <View style={[row.icon, { backgroundColor: `${iconColor}15` }]}>
        <MaterialCommunityIcons name={icon as never} size={15} color={iconColor} />
      </View>
      <Text style={[row.label, { color: colors.foreground }, isRTL && { textAlign: "right" }]}>
        {label}
      </Text>
      <View style={row.right}>
        {value && <Text style={[row.value, { color: colors.mutedForeground }]}>{value}</Text>}
        {toggle ? (
          <Switch
            value={toggleValue}
            onValueChange={(v) => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onToggle?.(v); }}
            trackColor={{ false: colors.muted, true: `${iconColor}55` }}
            thumbColor={toggleValue ? iconColor : colors.mutedForeground}
          />
        ) : (
          <Ionicons name="chevron-forward" size={13} color={colors.mutedForeground} />
        )}
      </View>
    </Pressable>
  );
}
const row = StyleSheet.create({
  wrap: { flexDirection: "row", alignItems: "center", padding: 14, gap: 12 },
  icon: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  label: { flex: 1, fontSize: 13, fontWeight: "600" },
  right: { flexDirection: "row", alignItems: "center", gap: 8 },
  value: { fontSize: 12 },
});

function OptimizationSlider({ level, onChange }: { level: number; onChange: (l: number) => void }) {
  const colors = useColors();
  const { t, isRTL } = useLang();
  const desc =
    level === 5 ? t.optimMax : level === 4 ? t.optimUltra
    : level === 3 ? t.optimBoost : level === 2 ? t.optimBalanced
    : t.optimEco;
  return (
    <View style={slider.wrapper}>
      <View style={[slider.header, isRTL && { flexDirection: "row-reverse" }]}>
        <Text style={[slider.label, { color: colors.foreground }]}>{t.optimizationLevel}</Text>
        <View style={[slider.badge, { backgroundColor: `${colors.primary}18`, borderColor: `${colors.primary}50` }]}>
          <Text style={[slider.badgeText, { color: colors.primary }]}>{OPTIMIZATION_LEVELS[level]}</Text>
        </View>
      </View>
      <View style={slider.steps}>
        {Array.from({ length: 5 }, (_, i) => {
          const val = i + 1;
          const active = val <= level;
          const c = val === 5 ? colors.destructive : val === 4 ? colors.warning : colors.primary;
          return (
            <Pressable
              key={val}
              style={[slider.step, { backgroundColor: active ? c : colors.muted, borderColor: active ? c : colors.border }]}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onChange(val); }}
            >
              <Text style={[slider.stepNum, { color: active ? "#05070f" : colors.mutedForeground }]}>{val}</Text>
            </Pressable>
          );
        })}
      </View>
      <Text style={[slider.desc, { color: colors.mutedForeground }, isRTL && { textAlign: "right" }]}>{desc}</Text>
    </View>
  );
}
const slider = StyleSheet.create({
  wrapper: { padding: 14, gap: 10 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  label: { fontSize: 13, fontWeight: "700" },
  badge: { borderWidth: 1, borderRadius: 6, paddingHorizontal: 10, paddingVertical: 3 },
  badgeText: { fontSize: 11, fontWeight: "700", letterSpacing: 1 },
  steps: { flexDirection: "row", gap: 8 },
  step: { flex: 1, height: 36, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  stepNum: { fontSize: 13, fontWeight: "800" },
  desc: { fontSize: 11, lineHeight: 16 },
});

function LanguageSelector() {
  const colors = useColors();
  const { lang, setLang, t } = useLang();
  return (
    <View style={lang_.wrapper}>
      <Text style={[lang_.label, { color: colors.mutedForeground }]}>{t.language}</Text>
      <View style={lang_.row}>
        {(["en", "ar"] as const).map((l) => {
          const active = lang === l;
          return (
            <Pressable
              key={l}
              style={[lang_.btn, { backgroundColor: active ? `${colors.primary}18` : colors.muted, borderColor: active ? colors.primary : colors.border }]}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setLang(l); }}
            >
              {active && <View style={[lang_.dot, { backgroundColor: colors.primary }]} />}
              <Text style={[lang_.btnText, { color: active ? colors.primary : colors.mutedForeground }]}>
                {l === "en" ? t.english : t.arabic}
              </Text>
              {active && <Ionicons name="checkmark-circle" size={14} color={colors.primary} />}
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
const lang_ = StyleSheet.create({
  wrapper: { padding: 14, gap: 10 },
  label: { fontSize: 11, fontWeight: "600", letterSpacing: 0.5 },
  row: { flexDirection: "row", gap: 10 },
  btn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, padding: 12, borderRadius: 10, borderWidth: 1 },
  dot: { width: 5, height: 5, borderRadius: 2.5 },
  btnText: { fontSize: 14, fontWeight: "700" },
});

function ShizukuStatusCard({
  granted,
  onGuidePress,
  isRTL,
}: {
  granted: boolean;
  onGuidePress: () => void;
  isRTL: boolean;
}) {
  const colors = useColors();
  const statusColor = granted ? colors.accent : colors.warning;

  const SHIZUKU_CMDS_STATUS = [
    { cmd: "low_latency_mode", status: "active", value: "1" },
    { cmd: "tc qdisc htb wlan0", status: "active", value: "100mbit" },
    { cmd: "iptables EF mark", status: "active", value: "udp:443" },
    { cmd: "ip rule fwmark", status: "active", value: "table 100" },
    { cmd: "sysctl tcp_fastopen", status: "active", value: "3" },
  ];

  return (
    <View style={[shiz.card, { backgroundColor: colors.card, borderColor: `${statusColor}35` }]}>
      <View style={[shiz.topBar, { backgroundColor: statusColor }]} />

      <View style={[shiz.header, isRTL && { flexDirection: "row-reverse" }]}>
        <View style={[shiz.icon, { backgroundColor: `${statusColor}15` }]}>
          <MaterialCommunityIcons name="shield-key" size={20} color={statusColor} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[shiz.title, { color: colors.foreground }]}>Shizuku Bridge</Text>
          <Text style={[shiz.sub, { color: colors.mutedForeground }]}>
            ADB Wireless Debug · Android 8–15
          </Text>
        </View>
        <View style={[shiz.statusBadge, { backgroundColor: `${statusColor}15`, borderColor: `${statusColor}50` }]}>
          <View style={[shiz.dot, { backgroundColor: statusColor }]} />
          <Text style={[shiz.statusText, { color: statusColor }]}>
            {granted ? "GRANTED" : "PENDING"}
          </Text>
        </View>
      </View>

      <View style={[shiz.divider, { backgroundColor: colors.border }]} />

      <View style={shiz.cmdGrid}>
        {SHIZUKU_CMDS_STATUS.map((item, i) => (
          <View key={i} style={[shiz.cmdItem, { backgroundColor: `${colors.accent}08`, borderColor: `${colors.accent}20` }]}>
            <View style={[shiz.cmdDot, { backgroundColor: colors.accent }]} />
            <Text style={[shiz.cmdName, { color: colors.mutedForeground }]} numberOfLines={1}>{item.cmd}</Text>
            <Text style={[shiz.cmdVal, { color: colors.accent }]}>{item.value}</Text>
          </View>
        ))}
      </View>

      <Pressable
        style={[shiz.guideBtn, { borderColor: `${colors.primary}40`, backgroundColor: `${colors.primary}0a` }]}
        onPress={onGuidePress}
      >
        <MaterialCommunityIcons name="android" size={14} color={colors.primary} />
        <Text style={[shiz.guideBtnText, { color: colors.primary }]}>Android Studio Guide & Shizuku Init</Text>
        <Ionicons name="chevron-forward" size={13} color={colors.primary} />
      </Pressable>
    </View>
  );
}
const shiz = StyleSheet.create({
  card: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  topBar: { height: 2, opacity: 0.7 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14, paddingBottom: 10 },
  icon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 14, fontWeight: "800" },
  sub: { fontSize: 10, marginTop: 1 },
  statusBadge: { flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  dot: { width: 5, height: 5, borderRadius: 2.5 },
  statusText: { fontSize: 9, fontWeight: "800", letterSpacing: 1.5 },
  divider: { height: 1, marginHorizontal: 14, marginBottom: 10 },
  cmdGrid: { flexDirection: "row", flexWrap: "wrap", gap: 6, paddingHorizontal: 14, paddingBottom: 12 },
  cmdItem: { flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 5, minWidth: "45%" },
  cmdDot: { width: 4, height: 4, borderRadius: 2 },
  cmdName: { fontSize: 9, flex: 1, fontFamily: "monospace" },
  cmdVal: { fontSize: 9, fontWeight: "700", fontFamily: "monospace" },
  guideBtn: { flexDirection: "row", alignItems: "center", gap: 8, margin: 10, padding: 10, borderRadius: 10, borderWidth: 1 },
  guideBtnText: { flex: 1, fontSize: 12, fontWeight: "700" },
});

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { t, isRTL } = useLang();
  const { aiEnabled, toggleAi, optimizationLevel, setOptimizationLevel, shizukuGranted, activeGame } = useNetworkOptimizer();
  const [foregroundService, setForegroundService] = useState(true);
  const [bootStart, setBootStart] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [showGuide, setShowGuide] = useState(false);
  const topPad = Platform.OS === "web" ? 60 : insets.top;

  return (
    <>
      <AndroidGuideModal visible={showGuide} onClose={() => setShowGuide(false)} />

      <ScrollView
        style={[styles.root, { backgroundColor: colors.background }]}
        contentContainerStyle={[styles.content, { paddingTop: topPad + 12, paddingBottom: insets.bottom + 48 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.header, isRTL && { alignItems: "flex-end" }]}>
          <Text style={[styles.title, { color: colors.primary }]}>{t.settings}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{t.settingsConfig}</Text>
        </View>

        {/* Language */}
        <Section title={t.languageSection}>
          <LanguageSelector />
        </Section>

        {/* Optimization */}
        <Section title={t.optimizationSection}>
          <OptimizationSlider level={optimizationLevel} onChange={setOptimizationLevel} />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <Row icon="robot" iconColor={colors.accent} label={t.aiPathSwitching} toggle toggleValue={aiEnabled} onToggle={toggleAi} isRTL={isRTL} />
          <Row icon="routes" iconColor={colors.primary} label={t.smartPathThreshold} value="40ms" last isRTL={isRTL} />
        </Section>

        {/* System */}
        <Section title={t.systemSection}>
          <Row icon="play-circle" iconColor={colors.primary} label={t.foregroundService} toggle toggleValue={foregroundService} onToggle={setForegroundService} isRTL={isRTL} />
          <Row icon="rocket-launch" iconColor={colors.secondary} label={t.startOnBoot} toggle toggleValue={bootStart} onToggle={setBootStart} isRTL={isRTL} />
          <Row icon="bell" iconColor={colors.warning} label={t.notifications} toggle toggleValue={notifications} onToggle={setNotifications} last isRTL={isRTL} />
        </Section>

        {/* Shizuku Status Card */}
        <View style={sect.wrapper}>
          <Text style={[sect.title, { color: colors.mutedForeground }]}>{t.shizukuSection}</Text>
          <ShizukuStatusCard
            granted={shizukuGranted}
            onGuidePress={() => setShowGuide(true)}
            isRTL={isRTL}
          />
        </View>

        {/* Live Shizuku Terminal */}
        <View style={sect.wrapper}>
          <Text style={[sect.title, { color: colors.mutedForeground }]}>SHIZUKU TERMINAL · LIVE EXECUTION</Text>
          <ShizukuTerminal activeGame={activeGame} />
        </View>

        {/* About */}
        <Section title={t.aboutSection}>
          <Row icon="information" iconColor={colors.primary} label={t.version} value="2.0.0 ULTRA" isRTL={isRTL} />
          <Row icon="dna" iconColor={colors.secondary} label={t.engine} value="GearUP + Shizuku Hybrid" isRTL={isRTL} />
          <Row
            icon="android"
            iconColor={colors.accent}
            label="Android Studio Guide"
            value="8–15"
            onPress={() => setShowGuide(true)}
            last
            isRTL={isRTL}
          />
        </Section>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 16 },
  header: { marginBottom: 2 },
  title: { fontSize: 24, fontWeight: "900", letterSpacing: 1 },
  subtitle: { fontSize: 10, marginTop: 2 },
  divider: { height: 1, marginHorizontal: 14 },
});
