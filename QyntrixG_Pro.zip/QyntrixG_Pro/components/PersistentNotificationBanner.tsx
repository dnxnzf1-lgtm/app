import { MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef } from "react";
import { Animated, Platform, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import { useNetworkOptimizer } from "@/context/NetworkOptimizerContext";

export default function PersistentNotificationBanner() {
  const colors = useColors();
  const { isOptimizing, ping, downloadSpeed, uploadSpeed, paths, currentPathId, activeGame, gameSensing } = useNetworkOptimizer();
  const slideAnim = useRef(new Animated.Value(-80)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const prevOptimizing = useRef(false);

  const activePath = paths.find((p) => p.id === currentPathId);

  useEffect(() => {
    if (isOptimizing && !prevOptimizing.current) {
      Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 80, friction: 12 }).start();
    } else if (!isOptimizing && prevOptimizing.current) {
      Animated.timing(slideAnim, { toValue: -80, duration: 250, useNativeDriver: true }).start();
    }
    prevOptimizing.current = isOptimizing;
  }, [isOptimizing, slideAnim]);

  useEffect(() => {
    if (isOptimizing) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 0.5, duration: 1000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        ])
      ).start();
    }
  }, [isOptimizing, pulseAnim]);

  const pingColor = ping < 30 ? colors.accent : ping < 60 ? colors.primary : colors.warning;

  return (
    <Animated.View
      style={[
        notif.wrap,
        {
          backgroundColor: "#060d1a",
          borderColor: gameSensing ? `${colors.secondary}55` : `${colors.primary}40`,
          transform: [{ translateY: slideAnim }],
        },
      ]}
      pointerEvents="none"
    >
      <View style={[notif.leftBar, { backgroundColor: gameSensing ? colors.secondary : colors.primary }]} />

      <View style={[notif.iconWrap, { backgroundColor: gameSensing ? `${colors.secondary}18` : `${colors.primary}18` }]}>
        <MaterialCommunityIcons
          name={activeGame ? "gamepad-variant" : "wifi-arrow-up-down"}
          size={18}
          color={gameSensing ? colors.secondary : colors.primary}
        />
      </View>

      <View style={notif.text}>
        <View style={notif.titleRow}>
          <Text style={[notif.title, { color: "#c9d5e0" }]}>
            {activeGame ? `${activeGame.emoji} ${activeGame.name}` : "QyntrixG"}
          </Text>
          <Animated.View style={[notif.liveDot, { backgroundColor: colors.accent, opacity: pulseAnim }]} />
          <Text style={[notif.live, { color: colors.accent }]}>LIVE</Text>
          {gameSensing && (
            <View style={[notif.ghostBadge, { backgroundColor: `${colors.secondary}20` }]}>
              <Text style={[notif.ghostText, { color: colors.secondary }]}>GHOST</Text>
            </View>
          )}
        </View>
        <Text style={notif.sub} numberOfLines={1}>
          <Text style={{ color: pingColor }}>⚡{ping}ms</Text>
          <Text style={{ color: "#4b6280" }}> · </Text>
          <Text style={{ color: colors.accent }}>↓{downloadSpeed.toFixed(0)}</Text>
          <Text style={{ color: "#4b6280" }}> · </Text>
          <Text style={{ color: colors.primary }}>↑{uploadSpeed.toFixed(0)} Mbps</Text>
          {activePath
            ? <Text style={{ color: "#4b6280" }}> · {activePath.name}</Text>
            : null
          }
        </Text>
      </View>

      <View style={notif.right}>
        <Text style={[notif.pathRegion, { color: "#4b6280" }]} numberOfLines={1}>
          {activePath?.region?.split(",")[0] ?? "—"}
        </Text>
        <View style={[notif.optBadge, { backgroundColor: `${colors.accent}15`, borderColor: `${colors.accent}35` }]}>
          <Text style={[notif.optText, { color: colors.accent }]}>OPT</Text>
        </View>
      </View>
    </Animated.View>
  );
}

const notif = StyleSheet.create({
  wrap: {
    position: "absolute",
    top: Platform.OS === "web" ? 0 : 0,
    left: 12,
    right: 12,
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
    zIndex: 999,
    gap: 10,
    paddingRight: 10,
    paddingVertical: 8,
    shadowColor: "#00d4ff",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 10,
  },
  leftBar: { width: 3, alignSelf: "stretch" },
  iconWrap: { width: 36, height: 36, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  text: { flex: 1, gap: 2 },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  title: { fontSize: 12, fontWeight: "700" },
  liveDot: { width: 5, height: 5, borderRadius: 2.5 },
  live: { fontSize: 8, fontWeight: "800", letterSpacing: 1.5 },
  ghostBadge: { borderRadius: 4, paddingHorizontal: 5, paddingVertical: 1 },
  ghostText: { fontSize: 7, fontWeight: "800", letterSpacing: 1 },
  sub: { fontSize: 10, fontFamily: "monospace" },
  right: { alignItems: "flex-end", gap: 4 },
  pathRegion: { fontSize: 8 },
  optBadge: { borderWidth: 1, borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2 },
  optText: { fontSize: 7, fontWeight: "800", letterSpacing: 1 },
});
