import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Game, GAMES } from "@/data/games";
import { useColors } from "@/hooks/useColors";

type Phase = "idle" | "analysis" | "done";

type AnalysisStep = {
  label: string;
  detail: string;
  done: boolean;
};

function ProgressBar({ value, color }: { value: Animated.Value; color: string }) {
  const width = value.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });
  return (
    <View style={[pb.track]}>
      <Animated.View style={[pb.fill, { width, backgroundColor: color }]} />
    </View>
  );
}
const pb = StyleSheet.create({
  track: { height: 3, backgroundColor: "#1a2f50", borderRadius: 2, overflow: "hidden" },
  fill: { height: "100%", borderRadius: 2 },
});

function DeepAnalysisModal({
  game,
  onComplete,
}: {
  game: Game;
  onComplete: () => void;
}) {
  const colors = useColors();
  const [steps, setSteps] = useState<AnalysisStep[]>([
    { label: "Identifying server IP ranges", detail: game.serverRanges.join("  ·  "), done: false },
    { label: "Mapping dedicated game ports", detail: `UDP: ${game.udpPorts.join(", ")}${game.tcpPorts.length ? `  TCP: ${game.tcpPorts.join(", ")}` : ""}`, done: false },
    { label: "Loading iptables priority rules", detail: `iptables -A PREROUTING -p udp --dport ${game.udpPorts[0]} -j DSCP --set-dscp-class EF`, done: false },
    { label: "Activating Shizuku port bridge", detail: `sh -c 'ip route add ${game.serverRanges[0]} dev wlan0 metric 1'`, done: false },
    { label: "Calibrating I/O sync matrix", detail: `Latency matching: ${game.name} · ${game.engineNote}`, done: false },
  ]);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 280, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, tension: 90 }),
    ]).start();

    const total = steps.length;
    const delays = [400, 900, 1500, 2100, 2700];

    delays.forEach((delay, i) => {
      setTimeout(() => {
        setSteps((prev) => prev.map((s, j) => (j === i ? { ...s, done: true } : s)));
        Animated.timing(progressAnim, {
          toValue: (i + 1) / total,
          duration: 350,
          useNativeDriver: false,
        }).start();
      }, delay);
    });

    const doneTimeout = setTimeout(() => {
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 0, duration: 250, useNativeDriver: true }),
        Animated.timing(scaleAnim, { toValue: 0.9, duration: 250, useNativeDriver: true }),
      ]).start(() => onComplete());
    }, 3400);

    return () => clearTimeout(doneTimeout);
  }, [game, onComplete, progressAnim, scaleAnim, fadeAnim, steps.length]);

  return (
    <Animated.View
      style={[
        analysis.card,
        {
          backgroundColor: colors.card,
          borderColor: `${colors.primary}50`,
          opacity: fadeAnim,
          transform: [{ scale: scaleAnim }],
        },
      ]}
    >
      <View style={[analysis.topBar, { backgroundColor: colors.primary }]} />
      <View style={analysis.header}>
        <Text style={analysis.emoji}>{game.emoji}</Text>
        <View style={{ flex: 1 }}>
          <Text style={[analysis.gameName, { color: colors.primary }]}>{game.name}</Text>
          <Text style={[analysis.category, { color: colors.mutedForeground }]}>
            {game.category} · {game.protocol}
          </Text>
        </View>
        <View style={[analysis.badge, { backgroundColor: `${colors.primary}18`, borderColor: `${colors.primary}50` }]}>
          <Text style={[analysis.badgeText, { color: colors.primary }]}>DEEP ANALYSIS</Text>
        </View>
      </View>
      <ProgressBar value={progressAnim} color={colors.primary} />
      <View style={analysis.steps}>
        {steps.map((step, i) => (
          <View key={i} style={analysis.step}>
            {step.done
              ? <MaterialCommunityIcons name="check-circle" size={14} color={colors.accent} />
              : <MaterialCommunityIcons name="loading" size={14} color={colors.primary} />
            }
            <View style={{ flex: 1 }}>
              <Text style={[analysis.stepLabel, { color: step.done ? colors.foreground : colors.mutedForeground }]}>
                {step.label}
              </Text>
              {step.done && (
                <Text style={[analysis.stepDetail, { color: colors.mutedForeground }]} numberOfLines={1}>
                  {step.detail}
                </Text>
              )}
            </View>
          </View>
        ))}
      </View>
    </Animated.View>
  );
}

const analysis = StyleSheet.create({
  card: { borderRadius: 16, borderWidth: 1, overflow: "hidden", margin: 16 },
  topBar: { height: 2, opacity: 0.8 },
  header: { flexDirection: "row", alignItems: "center", gap: 10, padding: 14, paddingBottom: 10 },
  emoji: { fontSize: 28 },
  gameName: { fontSize: 16, fontWeight: "800" },
  category: { fontSize: 10, marginTop: 2 },
  badge: { borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  badgeText: { fontSize: 8, fontWeight: "700", letterSpacing: 1.5 },
  steps: { paddingHorizontal: 14, paddingTop: 12, paddingBottom: 14, gap: 10 },
  step: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  stepLabel: { fontSize: 12, fontWeight: "600" },
  stepDetail: { fontSize: 9, marginTop: 2, fontFamily: "monospace" },
});

function GameCard({
  game,
  onSelect,
}: {
  game: Game;
  onSelect: (g: Game) => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      style={[gc.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
      onPress={() => onSelect(game)}
    >
      <Text style={gc.emoji}>{game.emoji}</Text>
      <Text style={[gc.name, { color: colors.foreground }]} numberOfLines={2}>{game.name}</Text>
      <View style={[gc.proto, { backgroundColor: `${colors.primary}18` }]}>
        <Text style={[gc.protoText, { color: colors.primary }]}>{game.protocol}</Text>
      </View>
      <Text style={[gc.cat, { color: colors.mutedForeground }]}>{game.category}</Text>
    </Pressable>
  );
}

const gc = StyleSheet.create({
  card: { width: "30%", borderRadius: 12, borderWidth: 1, padding: 10, alignItems: "center", gap: 5 },
  emoji: { fontSize: 28 },
  name: { fontSize: 10, fontWeight: "700", textAlign: "center", lineHeight: 13 },
  proto: { borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  protoText: { fontSize: 8, fontWeight: "700", letterSpacing: 1 },
  cat: { fontSize: 8, textAlign: "center" },
});

type GameLibraryProps = {
  visible: boolean;
  onClose: () => void;
  onSelect: (game: Game) => void;
};

export default function GameLibrary({ visible, onClose, onSelect }: GameLibraryProps) {
  const colors = useColors();
  const [search, setSearch] = useState("");
  const [analyzing, setAnalyzing] = useState<Game | null>(null);
  const slideAnim = useRef(new Animated.Value(600)).current;

  useEffect(() => {
    if (visible) {
      setSearch("");
      setAnalyzing(null);
      Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 80, friction: 12 }).start();
    } else {
      Animated.timing(slideAnim, { toValue: 600, duration: 250, useNativeDriver: true }).start();
    }
  }, [visible, slideAnim]);

  const filtered = GAMES.filter((g) =>
    g.name.toLowerCase().includes(search.toLowerCase()) ||
    g.category.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelect = (game: Game) => {
    setAnalyzing(game);
  };

  const handleAnalysisDone = () => {
    if (analyzing) {
      onSelect(analyzing);
      setAnalyzing(null);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <View style={[lib.backdrop]}>
        <Animated.View
          style={[lib.sheet, { backgroundColor: colors.card, transform: [{ translateY: slideAnim }] }]}
        >
          <View style={[lib.handle, { backgroundColor: colors.border }]} />
          <View style={lib.headerRow}>
            <View>
              <Text style={[lib.title, { color: colors.primary }]}>GAME LIBRARY</Text>
              <Text style={[lib.sub, { color: colors.mutedForeground }]}>
                Select a game for AI deep optimization
              </Text>
            </View>
            <Pressable onPress={onClose} style={[lib.closeBtn, { borderColor: colors.border }]}>
              <Ionicons name="close" size={18} color={colors.mutedForeground} />
            </Pressable>
          </View>

          <View style={[lib.searchWrap, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Ionicons name="search" size={14} color={colors.mutedForeground} />
            <TextInput
              style={[lib.search, { color: colors.foreground }]}
              placeholder="Search games..."
              placeholderTextColor={colors.mutedForeground}
              value={search}
              onChangeText={setSearch}
            />
          </View>

          {analyzing ? (
            <DeepAnalysisModal game={analyzing} onComplete={handleAnalysisDone} />
          ) : (
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={lib.grid}>
              {filtered.map((g) => <GameCard key={g.id} game={g} onSelect={handleSelect} />)}
            </ScrollView>
          )}
        </Animated.View>
      </View>
    </Modal>
  );
}

const lib = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.75)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingBottom: 40, maxHeight: "88%" },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginTop: 10, marginBottom: 4 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", padding: 16, paddingTop: 12 },
  title: { fontSize: 18, fontWeight: "900", letterSpacing: 1.5 },
  sub: { fontSize: 10, marginTop: 3 },
  closeBtn: { padding: 8, borderRadius: 8, borderWidth: 1 },
  searchWrap: { flexDirection: "row", alignItems: "center", gap: 8, marginHorizontal: 16, padding: 10, borderRadius: 10, borderWidth: 1, marginBottom: 12 },
  search: { flex: 1, fontSize: 13 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10, paddingHorizontal: 16, paddingBottom: 20, justifyContent: "flex-start" },
});
