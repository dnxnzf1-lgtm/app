import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef, useState } from "react";
import { Animated, Modal, ScrollView, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import { NetworkPath } from "@/context/NetworkOptimizerContext";
import { useLang } from "@/context/LanguageContext";

type PathState = "waiting" | "probing" | "done";

type BestPathDiscoveryProps = {
  visible: boolean;
  paths: NetworkPath[];
  onComplete: (winnerId: number) => void;
};

function ProbingDots({ color }: { color: string }) {
  const d1 = useRef(new Animated.Value(0.2)).current;
  const d2 = useRef(new Animated.Value(0.2)).current;
  const d3 = useRef(new Animated.Value(0.2)).current;

  useEffect(() => {
    const loop = (anim: Animated.Value, delay: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(anim, { toValue: 1, duration: 300, useNativeDriver: true }),
          Animated.timing(anim, { toValue: 0.2, duration: 300, useNativeDriver: true }),
          Animated.delay(600 - delay),
        ])
      ).start();
    loop(d1, 0);
    loop(d2, 200);
    loop(d3, 400);
  }, [d1, d2, d3]);

  return (
    <View style={{ flexDirection: "row", gap: 3, alignItems: "center" }}>
      {[d1, d2, d3].map((d, i) => (
        <Animated.View
          key={i}
          style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: color, opacity: d }}
        />
      ))}
    </View>
  );
}

function PathRow({
  path,
  state,
  rank,
  isWinner,
}: {
  path: NetworkPath;
  state: PathState;
  rank: number | null;
  isWinner: boolean;
}) {
  const colors = useColors();
  const flashAnim = useRef(new Animated.Value(isWinner ? 0 : 1)).current;

  useEffect(() => {
    if (isWinner) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(flashAnim, { toValue: 1, duration: 600, useNativeDriver: false }),
          Animated.timing(flashAnim, { toValue: 0.3, duration: 600, useNativeDriver: false }),
        ])
      ).start();
    }
  }, [isWinner, flashAnim]);

  const borderColor = isWinner
    ? flashAnim.interpolate({ inputRange: [0, 1], outputRange: [`${colors.accent}30`, `${colors.accent}cc`] })
    : `${colors.border}`;

  const latColor =
    path.latency < 25 ? colors.accent
    : path.latency < 60 ? colors.primary
    : colors.warning;

  return (
    <Animated.View
      style={[
        styles.pathRow,
        {
          backgroundColor: isWinner ? `${colors.accent}10` : colors.surface,
          borderColor,
        },
      ]}
    >
      <View style={styles.pathLeft}>
        <Text style={[styles.pathName, { color: isWinner ? colors.accent : colors.foreground }]} numberOfLines={1}>
          {path.name}
        </Text>
        <Text style={[styles.pathRegion, { color: colors.mutedForeground }]} numberOfLines={1}>
          {path.region}
        </Text>
      </View>

      <View style={styles.pathRight}>
        {state === "waiting" && (
          <Text style={[styles.waiting, { color: colors.mutedForeground }]}>—</Text>
        )}
        {state === "probing" && <ProbingDots color={colors.primary} />}
        {state === "done" && (
          <View style={styles.doneBlock}>
            <Text style={[styles.latencyVal, { color: isWinner ? colors.accent : latColor }]}>
              {path.latency}ms
            </Text>
            {isWinner && (
              <Ionicons name="checkmark-circle" size={14} color={colors.accent} />
            )}
          </View>
        )}
      </View>
    </Animated.View>
  );
}

export default function BestPathDiscovery({ visible, paths, onComplete }: BestPathDiscoveryProps) {
  const colors = useColors();
  const { t } = useLang();
  const [pathStates, setPathStates] = useState<PathState[]>(paths.map(() => "waiting"));
  const [winnerId, setWinnerId] = useState<number | null>(null);
  const [phase, setPhase] = useState<"probing" | "complete">("probing");
  const [pathRanks, setPathRanks] = useState<(number | null)[]>(paths.map(() => null));
  const scaleAnim = useRef(new Animated.Value(0.88)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!visible) {
      setPathStates(paths.map(() => "waiting"));
      setWinnerId(null);
      setPhase("probing");
      setPathRanks(paths.map(() => null));
      scaleAnim.setValue(0.88);
      fadeAnim.setValue(0);
      return;
    }

    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, tension: 90 }),
    ]).start();

    // All paths start probing simultaneously
    setPathStates(paths.map(() => "probing"));

    // Results come in at different times based on latency
    const sorted = [...paths].sort((a, b) => a.latency - b.latency);
    const timeouts: ReturnType<typeof setTimeout>[] = [];

    sorted.forEach((path, rank) => {
      const delay = 800 + (path.latency / sorted[sorted.length - 1].latency) * 1800;
      const t = setTimeout(() => {
        setPathStates((prev) => {
          const next = [...prev];
          next[path.id - 1] = "done";
          return next;
        });
        setPathRanks((prev) => {
          const next = [...prev];
          next[path.id - 1] = rank + 1;
          return next;
        });
      }, delay);
      timeouts.push(t);
    });

    // Winner announcement
    const winnerPath = sorted[0];
    const winnerTimeout = setTimeout(() => {
      setWinnerId(winnerPath.id);
      setPhase("complete");
    }, 2800);

    // Auto-close
    const closeTimeout = setTimeout(() => {
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
        Animated.timing(scaleAnim, { toValue: 0.9, duration: 300, useNativeDriver: true }),
      ]).start(() => onComplete(winnerPath.id));
    }, 4200);

    timeouts.push(winnerTimeout, closeTimeout);
    return () => timeouts.forEach(clearTimeout);
  }, [visible, paths, onComplete, scaleAnim, fadeAnim]);

  return (
    <Modal visible={visible} transparent animationType="none">
      <View style={styles.backdrop}>
        <Animated.View
          style={[
            styles.card,
            {
              backgroundColor: colors.card,
              borderColor: phase === "complete" ? `${colors.accent}60` : `${colors.primary}40`,
              opacity: fadeAnim,
              transform: [{ scale: scaleAnim }],
            },
          ]}
        >
          <View style={[styles.cardTop, { backgroundColor: phase === "complete" ? colors.accent : colors.primary }]} />

          <View style={styles.header}>
            <MaterialCommunityIcons
              name={phase === "complete" ? "check-network" : "radar"}
              size={20}
              color={phase === "complete" ? colors.accent : colors.primary}
            />
            <Text style={[styles.title, { color: phase === "complete" ? colors.accent : colors.primary }]}>
              {phase === "complete" ? t.discoveryComplete : t.discoveryRunning}
            </Text>
            {phase === "probing" && <ProbingDots color={colors.primary} />}
          </View>

          {winnerId !== null && phase === "complete" && (
            <View style={[styles.winnerBanner, { backgroundColor: `${colors.accent}12`, borderColor: `${colors.accent}40` }]}>
              <Ionicons name="trophy" size={16} color={colors.accent} />
              <Text style={[styles.winnerText, { color: colors.accent }]}>
                {paths.find((p) => p.id === winnerId)?.name} · {paths.find((p) => p.id === winnerId)?.region}
              </Text>
              <Text style={[styles.winnerMs, { color: colors.accent }]}>
                {paths.find((p) => p.id === winnerId)?.latency}ms
              </Text>
            </View>
          )}

          <ScrollView
            style={styles.pathList}
            showsVerticalScrollIndicator={false}
            scrollEnabled
          >
            {paths.map((path, i) => (
              <PathRow
                key={path.id}
                path={path}
                state={pathStates[i] ?? "waiting"}
                rank={pathRanks[i]}
                isWinner={path.id === winnerId}
              />
            ))}
          </ScrollView>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.82)", alignItems: "center", justifyContent: "center", padding: 20 },
  card: { width: "100%", maxWidth: 380, borderRadius: 16, borderWidth: 1, overflow: "hidden", maxHeight: 520 },
  cardTop: { height: 2, opacity: 0.8 },
  header: { flexDirection: "row", alignItems: "center", gap: 10, padding: 14, paddingBottom: 10 },
  title: { flex: 1, fontSize: 14, fontWeight: "800", letterSpacing: 1.5, textTransform: "uppercase" },
  winnerBanner: { flexDirection: "row", alignItems: "center", gap: 8, marginHorizontal: 14, padding: 10, borderRadius: 8, borderWidth: 1, marginBottom: 6 },
  winnerText: { flex: 1, fontSize: 12, fontWeight: "700" },
  winnerMs: { fontSize: 14, fontWeight: "900" },
  pathList: { paddingHorizontal: 14, paddingBottom: 14, maxHeight: 380 },
  pathRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 10, borderRadius: 8, borderWidth: 1, marginBottom: 5 },
  pathLeft: { flex: 1, paddingRight: 8 },
  pathName: { fontSize: 12, fontWeight: "700" },
  pathRegion: { fontSize: 9, marginTop: 1 },
  pathRight: { minWidth: 52, alignItems: "flex-end", justifyContent: "center" },
  waiting: { fontSize: 12 },
  doneBlock: { flexDirection: "row", alignItems: "center", gap: 4 },
  latencyVal: { fontSize: 13, fontWeight: "800" },
});
