import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

type StatCardProps = {
  label: string;
  value: string;
  unit: string;
  color?: string;
  icon?: string;
};

export default function StatCard({ label, value, unit, color, icon }: StatCardProps) {
  const colors = useColors();
  const accentColor = color || colors.primary;
  const scaleAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 1.04, duration: 120, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 120, useNativeDriver: true }),
    ]).start();
  }, [value, scaleAnim]);

  return (
    <Animated.View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: `${accentColor}40`,
          transform: [{ scale: scaleAnim }],
        },
      ]}
    >
      <View style={[styles.glowBar, { backgroundColor: accentColor }]} />
      {icon ? <Text style={[styles.icon, { color: accentColor }]}>{icon}</Text> : null}
      <Text style={[styles.value, { color: accentColor }]}>{value}</Text>
      <Text style={[styles.unit, { color: colors.mutedForeground }]}>{unit}</Text>
      <Text style={[styles.label, { color: colors.mutedForeground }]}>{label}</Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 14,
    paddingHorizontal: 10,
    alignItems: "center",
    overflow: "hidden",
  },
  glowBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    opacity: 0.8,
  },
  icon: {
    fontSize: 16,
    marginBottom: 2,
  },
  value: {
    fontSize: 24,
    fontWeight: "800",
    letterSpacing: 1,
  },
  unit: {
    fontSize: 10,
    fontWeight: "600",
    letterSpacing: 1,
    marginTop: 1,
  },
  label: {
    fontSize: 9,
    fontWeight: "500",
    letterSpacing: 1.5,
    textTransform: "uppercase",
    marginTop: 4,
  },
});
