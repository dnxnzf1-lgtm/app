import { MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef, useState } from "react";
import { Animated, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Game } from "@/data/games";
import { useColors } from "@/hooks/useColors";

type RecoveryEvent = {
  id: number;
  path: string;
  timeMs: number;
  recoveredIn: string;
};

type ActiveGameCardProps = {
  game: Game;
  packetRecoveryCount: number;
  recoveryEvents: RecoveryEvent[];
  ioSyncDelta: number;
  inputLatency: number;
  serverResponse: number;
  loadBalance: { pathId: number; name: string; percent: number }[];
  onClear: () => void;
};

function SyncMeter({ input, server, delta }: { input: number; server: number; delta: number }) {
  const colors = useColors();
  const pulseAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1, duration: 600, useNativeDriver: false }),
        Animated.timing(pulseAnim, { toValue: 0, duration: 600, useNativeDriver: false }),
      ])
    ).start();
  }, [pulseAnim]);

  const syncColor = delta < 2 ? colors.accent : delta < 5 ? colors.primary : colors.warning;

  return (
    <View style={[sync.card, { backgroundColor: colors.surface, borderColor: `${syncColor}30` }]}>
      <Text style={[sync.title, { color: colors.mutedForeground }]}>I/O SYNC MATRIX</Text>
      <View style={sync.row}>
        <View style={sync.col}>
          <MaterialCommunityIcons name="gesture-tap" size={16} color={colors.primary} />
          <Text style={[sync.val, { color: colors.primary }]}>{input.toFixed(1)}ms</Text>
          <Text style={[sync.label, { color: colors.mutedForeground }]}>Touch Input</Text>
        </View>
        <View style={sync.arrow}>
          <Animated.View style={[sync.dot, {
            backgroundColor: syncColor,
            opacity: pulseAnim.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] }),
          }]} />
          <View style={[sync.line, { backgroundColor: `${syncColor}40` }]} />
          <Text style={[sync.delta, { color: syncColor }]}>Δ{delta.toFixed(1)}ms</Text>
        </View>
        <View style={sync.col}>
          <MaterialCommunityIcons name="server-network" size={16} color={colors.accent} />
          <Text style={[sync.val, { color: colors.accent }]}>{server.toFixed(1)}ms</Text>
          <Text style={[sync.label, { color: colors.mutedForeground }]}>Server ACK</Text>
        </View>
      </View>
    </View>
  );
}

const sync = StyleSheet.create({
  card: { borderRadius: 10, borderWidth: 1, padding: 12, gap: 8 },
  title: { fontSize: 8, fontWeight: "700", letterSpacing: 2, textAlign: "center" },
  row: { flexDirection: "row", alignItems: "center", gap: 8 },
  col: { flex: 1, alignItems: "center", gap: 3 },
  val: { fontSize: 16, fontWeight: "800" },
  label: { fontSize: 8, letterSpacing: 1 },
  arrow: { flex: 0.8, alignItems: "center", gap: 2 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  line: { width: "100%", height: 1.5, borderRadius: 1 },
  delta: { fontSize: 9, fontWeight: "700" },
});

function LoadBalancerMini({ items }: { items: { pathId: number; name: string; percent: number }[] }) {
  const colors = useColors();
  const top5 = items.slice(0, 5);
  return (
    <View style={[lb.card, { backgroundColor: colors.surface, borderColor: `${colors.secondary}25` }]}>
      <Text style={[lb.title, { color: colors.mutedForeground }]}>UDP LOAD BALANCER · {items.length} PATHS</Text>
      {top5.map((item) => {
        const color = item.percent > 25 ? colors.primary : item.percent > 15 ? colors.accent : colors.secondary;
        return (
          <View key={item.pathId} style={lb.row}>
            <Text style={[lb.name, { color: colors.mutedForeground }]}>{item.name}</Text>
            <View style={[lb.track, { backgroundColor: colors.muted }]}>
              <View style={[lb.bar, { width: `${item.percent}%`, backgroundColor: color }]} />
            </View>
            <Text style={[lb.pct, { color }]}>{item.percent}%</Text>
          </View>
        );
      })}
    </View>
  );
}

const lb = StyleSheet.create({
  card: { borderRadius: 10, borderWidth: 1, padding: 12, gap: 6 },
  title: { fontSize: 8, fontWeight: "700", letterSpacing: 2, marginBottom: 2 },
  row: { flexDirection: "row", alignItems: "center", gap: 8 },
  name: { fontSize: 9, fontWeight: "600", width: 62 },
  track: { flex: 1, height: 4, borderRadius: 2, overflow: "hidden" },
  bar: { height: "100%", borderRadius: 2 },
  pct: { fontSize: 10, fontWeight: "700", width: 32, textAlign: "right" },
});

function PacketRecoveryLog({ events }: { events: RecoveryEvent[] }) {
  const colors = useColors();
  if (events.length === 0) return null;
  return (
    <View style={[prl.card, { backgroundColor: colors.surface, borderColor: `${colors.accent}25` }]}>
      <Text style={[prl.title, { color: colors.mutedForeground }]}>FAST-RETRANSMIT LOG</Text>
      {events.slice(0, 4).map((e) => (
        <View key={e.id} style={prl.row}>
          <MaterialCommunityIcons name="restore" size={11} color={colors.accent} />
          <Text style={[prl.text, { color: colors.mutedForeground }]}>
            <Text style={{ color: colors.accent }}>RECOVERED </Text>
            via {e.path} · {e.recoveredIn}
          </Text>
        </View>
      ))}
    </View>
  );
}

const prl = StyleSheet.create({
  card: { borderRadius: 10, borderWidth: 1, padding: 10, gap: 6 },
  title: { fontSize: 8, fontWeight: "700", letterSpacing: 2, marginBottom: 2 },
  row: { flexDirection: "row", alignItems: "center", gap: 6 },
  text: { fontSize: 10, flex: 1 },
});

export default function ActiveGameCard({
  game,
  packetRecoveryCount,
  recoveryEvents,
  ioSyncDelta,
  inputLatency,
  serverResponse,
  loadBalance,
  onClear,
}: ActiveGameCardProps) {
  const colors = useColors();
  const glowAnim = useRef(new Animated.Value(0)).current;
  const counterAnim = useRef(new Animated.Value(0)).current;
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, { toValue: 1, duration: 1400, useNativeDriver: false }),
        Animated.timing(glowAnim, { toValue: 0.2, duration: 1400, useNativeDriver: false }),
      ])
    ).start();
  }, [glowAnim]);

  useEffect(() => {
    Animated.spring(counterAnim, { toValue: packetRecoveryCount, useNativeDriver: true, tension: 120 }).start();
  }, [packetRecoveryCount, counterAnim]);

  const cardBorder = glowAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [`${colors.primary}20`, `${colors.primary}55`],
  });

  return (
    <Animated.View style={[styles.card, { backgroundColor: colors.card, borderColor: cardBorder }]}>
      <View style={[styles.topBar, { backgroundColor: colors.primary }]} />

      {/* Header row */}
      <View style={styles.header}>
        <Text style={styles.emoji}>{game.emoji}</Text>
        <View style={{ flex: 1 }}>
          <Text style={[styles.gameName, { color: colors.foreground }]}>{game.name}</Text>
          <Text style={[styles.category, { color: colors.mutedForeground }]}>
            {game.category} · {game.region}
          </Text>
        </View>
        <Pressable style={[styles.clearBtn, { borderColor: colors.border }]} onPress={onClear}>
          <MaterialCommunityIcons name="close" size={14} color={colors.mutedForeground} />
        </Pressable>
      </View>

      {/* Port Forwarding Status */}
      <View style={[styles.portRow, { backgroundColor: `${colors.accent}0a`, borderColor: `${colors.accent}28` }]}>
        <MaterialCommunityIcons name="connection" size={13} color={colors.accent} />
        <Text style={[styles.portLabel, { color: colors.accent }]}>DEDICATED PORT BRIDGE · SHIZUKU</Text>
        <View style={[styles.activeBadge, { backgroundColor: `${colors.accent}18` }]}>
          <View style={[styles.activeDot, { backgroundColor: colors.accent }]} />
          <Text style={[styles.activeText, { color: colors.accent }]}>ACTIVE</Text>
        </View>
      </View>

      {/* Port list */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.portList}>
        {game.udpPorts.map((p) => (
          <View key={`u${p}`} style={[styles.portChip, { backgroundColor: `${colors.primary}15`, borderColor: `${colors.primary}40` }]}>
            <Text style={[styles.portNum, { color: colors.primary }]}>{p}</Text>
            <Text style={[styles.portProto, { color: `${colors.primary}80` }]}>UDP</Text>
          </View>
        ))}
        {game.tcpPorts.map((p) => (
          <View key={`t${p}`} style={[styles.portChip, { backgroundColor: `${colors.secondary}12`, borderColor: `${colors.secondary}35` }]}>
            <Text style={[styles.portNum, { color: colors.secondary }]}>{p}</Text>
            <Text style={[styles.portProto, { color: `${colors.secondary}80` }]}>TCP</Text>
          </View>
        ))}
      </ScrollView>

      {/* Stats row: Packet Recovery + Engine Note */}
      <View style={styles.statsRow}>
        <View style={[styles.statBox, { backgroundColor: `${colors.accent}0d`, borderColor: `${colors.accent}28` }]}>
          <MaterialCommunityIcons name="restore" size={14} color={colors.accent} />
          <Text style={[styles.statVal, { color: colors.accent }]}>{packetRecoveryCount}</Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>RECOVERED</Text>
        </View>
        <View style={[styles.statBox, { backgroundColor: `${colors.primary}0d`, borderColor: `${colors.primary}28` }]}>
          <MaterialCommunityIcons name="shield-check" size={14} color={colors.primary} />
          <Text style={[styles.statVal, { color: colors.primary }]}>0.1ms</Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>INJECT TIME</Text>
        </View>
        <View style={[styles.statBox, { backgroundColor: `${colors.secondary}0d`, borderColor: `${colors.secondary}28` }]}>
          <MaterialCommunityIcons name="infinity" size={14} color={colors.secondary} />
          <Text style={[styles.statVal, { color: colors.secondary }]}>∞</Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>STABILITY</Text>
        </View>
      </View>

      {/* Engine note */}
      <Text style={[styles.engineNote, { color: colors.mutedForeground, backgroundColor: `${colors.muted}` }]}>
        ⚙ {game.engineNote}
      </Text>

      {/* Expand button */}
      <Pressable
        style={[styles.expandBtn, { borderTopColor: colors.border }]}
        onPress={() => setExpanded((v) => !v)}
      >
        <Text style={[styles.expandText, { color: colors.mutedForeground }]}>
          {expanded ? "Hide Advanced Details ↑" : "Show I/O Sync · Load Balancer · Recovery Log ↓"}
        </Text>
      </Pressable>

      {expanded && (
        <View style={styles.advanced}>
          <SyncMeter input={inputLatency} server={serverResponse} delta={ioSyncDelta} />
          <LoadBalancerMini items={loadBalance} />
          <PacketRecoveryLog events={recoveryEvents} />
        </View>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  topBar: { height: 2, opacity: 0.8 },
  header: { flexDirection: "row", alignItems: "center", padding: 12, paddingBottom: 8, gap: 10 },
  emoji: { fontSize: 28 },
  gameName: { fontSize: 15, fontWeight: "800" },
  category: { fontSize: 9, marginTop: 1 },
  clearBtn: { padding: 6, borderRadius: 8, borderWidth: 1 },
  portRow: { flexDirection: "row", alignItems: "center", gap: 6, marginHorizontal: 12, padding: 8, borderRadius: 8, borderWidth: 1 },
  portLabel: { flex: 1, fontSize: 8, fontWeight: "700", letterSpacing: 1.5 },
  activeBadge: { flexDirection: "row", alignItems: "center", gap: 4, padding: 4, borderRadius: 4 },
  activeDot: { width: 5, height: 5, borderRadius: 2.5 },
  activeText: { fontSize: 8, fontWeight: "700", letterSpacing: 1 },
  portList: { flexDirection: "row", gap: 6, paddingHorizontal: 12, paddingVertical: 8 },
  portChip: { alignItems: "center", borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  portNum: { fontSize: 12, fontWeight: "800" },
  portProto: { fontSize: 7, fontWeight: "700", letterSpacing: 1 },
  statsRow: { flexDirection: "row", gap: 8, paddingHorizontal: 12, paddingBottom: 8 },
  statBox: { flex: 1, alignItems: "center", gap: 2, padding: 8, borderRadius: 8, borderWidth: 1 },
  statVal: { fontSize: 16, fontWeight: "900" },
  statLabel: { fontSize: 7, fontWeight: "700", letterSpacing: 1.5 },
  engineNote: { fontSize: 9, marginHorizontal: 12, padding: 8, borderRadius: 6, marginBottom: 4 },
  expandBtn: { paddingVertical: 10, paddingHorizontal: 14, borderTopWidth: 1, alignItems: "center" },
  expandText: { fontSize: 10, fontWeight: "600" },
  advanced: { paddingHorizontal: 12, paddingBottom: 12, gap: 8 },
});
