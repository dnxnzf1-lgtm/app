import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef, useState } from "react";
import { Animated, Modal, StyleSheet, Text, View } from "react-native";
import { useLang } from "@/context/LanguageContext";
import { useColors } from "@/hooks/useColors";

type StepStatus = "pending" | "running" | "done";

type Step = {
  key: "step1" | "step2" | "step3";
  status: StepStatus;
};

type OptimizationPopupProps = {
  visible: boolean;
  onComplete: () => void;
};

function StepRow({ label, status, color }: { label: string; status: StepStatus; color: string }) {
  const colors = useColors();
  const spin = useRef(new Animated.Value(0)).current;
  const dotScale = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (status === "running") {
      Animated.loop(
        Animated.timing(spin, { toValue: 1, duration: 800, useNativeDriver: true })
      ).start();
    } else {
      spin.stopAnimation();
      spin.setValue(0);
    }
    if (status === "done") {
      Animated.spring(dotScale, { toValue: 1, useNativeDriver: true, tension: 120 }).start();
    } else {
      dotScale.setValue(0);
    }
  }, [status, spin, dotScale]);

  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ["0deg", "360deg"] });

  return (
    <View style={rowStyles.row}>
      <View style={rowStyles.iconWrap}>
        {status === "pending" && (
          <View style={[rowStyles.pending, { borderColor: colors.mutedForeground }]} />
        )}
        {status === "running" && (
          <Animated.View style={{ transform: [{ rotate }] }}>
            <MaterialCommunityIcons name="loading" size={18} color={color} />
          </Animated.View>
        )}
        {status === "done" && (
          <Animated.View style={{ transform: [{ scale: dotScale }] }}>
            <Ionicons name="checkmark-circle" size={20} color={colors.accent} />
          </Animated.View>
        )}
      </View>
      <Text
        style={[
          rowStyles.label,
          {
            color:
              status === "done"
                ? colors.accent
                : status === "running"
                ? color
                : colors.mutedForeground,
            fontWeight: status === "running" ? "700" : "500",
          },
        ]}
      >
        {label}
      </Text>
      {status === "done" && (
        <Text style={[rowStyles.check, { color: colors.accent }]}>[✓]</Text>
      )}
    </View>
  );
}

const rowStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 8 },
  iconWrap: { width: 24, alignItems: "center" },
  pending: { width: 16, height: 16, borderRadius: 8, borderWidth: 1.5 },
  label: { flex: 1, fontSize: 14, letterSpacing: 0.3 },
  check: { fontSize: 13, fontWeight: "700" },
});

export default function OptimizationPopup({ visible, onComplete }: OptimizationPopupProps) {
  const colors = useColors();
  const { t, isRTL } = useLang();
  const [currentStep, setCurrentStep] = useState(-1);
  const [finished, setFinished] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.85)).current;
  const completedOpacity = useRef(new Animated.Value(0)).current;

  const STEPS: Step[] = [
    { key: "step1", status: currentStep === 0 ? "running" : currentStep > 0 ? "done" : "pending" },
    { key: "step2", status: currentStep === 1 ? "running" : currentStep > 1 ? "done" : "pending" },
    { key: "step3", status: currentStep === 2 ? "running" : currentStep > 2 ? "done" : "pending" },
  ];

  useEffect(() => {
    if (!visible) {
      setCurrentStep(-1);
      setFinished(false);
      fadeAnim.setValue(0);
      scaleAnim.setValue(0.85);
      completedOpacity.setValue(0);
      return;
    }

    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, tension: 100 }),
    ]).start();

    const t1 = setTimeout(() => setCurrentStep(0), 400);
    const t2 = setTimeout(() => setCurrentStep(1), 1400);
    const t3 = setTimeout(() => setCurrentStep(2), 2400);
    const t4 = setTimeout(() => {
      setCurrentStep(3);
      setFinished(true);
      Animated.timing(completedOpacity, { toValue: 1, duration: 400, useNativeDriver: true }).start();
    }, 3400);
    const t5 = setTimeout(() => {
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
        Animated.timing(scaleAnim, { toValue: 0.9, duration: 300, useNativeDriver: true }),
      ]).start(() => onComplete());
    }, 4600);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, [visible, fadeAnim, scaleAnim, completedOpacity, onComplete]);

  return (
    <Modal visible={visible} transparent animationType="none">
      <View style={styles.backdrop}>
        <Animated.View
          style={[
            styles.card,
            {
              backgroundColor: colors.card,
              borderColor: `${colors.primary}50`,
              opacity: fadeAnim,
              transform: [{ scale: scaleAnim }],
            },
          ]}
        >
          <View style={[styles.topBar, { backgroundColor: colors.primary }]} />

          <View style={[styles.header, isRTL && { flexDirection: "row-reverse" }]}>
            <MaterialCommunityIcons name="robot" size={22} color={colors.primary} />
            <Text style={[styles.title, { color: colors.primary }]}>{t.popupTitle}</Text>
          </View>

          <View style={[styles.divider, { backgroundColor: colors.border }]} />

          <View style={styles.steps}>
            {STEPS.map((step) => (
              <StepRow
                key={step.key}
                label={t[step.key]}
                status={step.status}
                color={colors.primary}
              />
            ))}
          </View>

          {finished && (
            <Animated.View
              style={[styles.completedBlock, { opacity: completedOpacity, borderColor: `${colors.accent}40` }]}
            >
              <View style={[styles.completedBg, { backgroundColor: `${colors.accent}12` }]} />
              <Ionicons name="checkmark-done-circle" size={28} color={colors.accent} />
              <View>
                <Text style={[styles.completedText, { color: colors.accent }]}>{t.completed}</Text>
                <Text style={[styles.completedSub, { color: colors.mutedForeground }]}>
                  {t.completedSub}
                </Text>
              </View>
            </Animated.View>
          )}
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.75)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  card: {
    width: "100%",
    maxWidth: 360,
    borderRadius: 16,
    borderWidth: 1,
    overflow: "hidden",
    padding: 20,
    gap: 14,
  },
  topBar: { position: "absolute", top: 0, left: 0, right: 0, height: 2, opacity: 0.8 },
  header: { flexDirection: "row", alignItems: "center", gap: 10 },
  title: { fontSize: 17, fontWeight: "800", letterSpacing: 1.5 },
  divider: { height: 1, opacity: 0.5 },
  steps: { gap: 2 },
  completedBlock: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
    overflow: "hidden",
  },
  completedBg: { ...StyleSheet.absoluteFillObject },
  completedText: { fontSize: 15, fontWeight: "800", letterSpacing: 0.5 },
  completedSub: { fontSize: 11, marginTop: 2 },
});
