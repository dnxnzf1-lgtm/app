import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";
import Svg, {
  Defs,
  LinearGradient,
  Path,
  Polygon,
  Polyline,
  Stop,
} from "react-native-svg";
import { useColors } from "@/hooks/useColors";

type WaveformMeterProps = {
  pingHistory: number[];
  currentPing: number;
  jitter: number;
  label?: string;
};

function buildPath(values: number[], w: number, h: number): { line: string; fill: string } {
  if (values.length < 2) return { line: "", fill: "" };
  const minV = Math.max(0, Math.min(...values) - 5);
  const maxV = Math.max(...values) + 10;
  const range = maxV - minV || 1;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * w;
    const y = h - ((v - minV) / range) * h * 0.85 - h * 0.05;
    return [x, y] as [number, number];
  });

  const smooth = (points: [number, number][]) => {
    let d = `M ${points[0][0]} ${points[0][1]}`;
    for (let i = 1; i < points.length; i++) {
      const [x0, y0] = points[i - 1];
      const [x1, y1] = points[i];
      const cx = (x0 + x1) / 2;
      d += ` C ${cx} ${y0} ${cx} ${y1} ${x1} ${y1}`;
    }
    return d;
  };

  const linePath = smooth(pts);
  const fillPath = `${linePath} L ${pts[pts.length - 1][0]} ${h} L 0 ${h} Z`;
  return { line: linePath, fill: fillPath };
}

export default function WaveformMeter({
  pingHistory,
  currentPing,
  jitter,
  label = "NETWORK WAVEFORM",
}: WaveformMeterProps) {
  const colors = useColors();
  const W = 320;
  const H = 70;
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const stability = jitter < 3 ? "excellent" : jitter < 6 ? "good" : jitter < 12 ? "fair" : "poor";
  const waveColor =
    stability === "excellent" ? colors.accent
    : stability === "good" ? colors.primary
    : stability === "fair" ? colors.warning
    : colors.destructive;

  useEffect(() => {
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0.5, duration: 80, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 180, useNativeDriver: true }),
    ]).start();
  }, [pingHistory.length, fadeAnim]);

  const { line, fill } = buildPath(pingHistory, W, H);

  const precisionPing = currentPing + Math.random() * 0.9;
  const responseTime = (precisionPing * 0.95 + Math.random() * 0.5).toFixed(2);

  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: `${waveColor}28` }]}>
      <View style={[styles.topGlow, { backgroundColor: waveColor }]} />

      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={[styles.liveDot, { backgroundColor: waveColor }]} />
          <Text style={[styles.label, { color: colors.mutedForeground }]}>{label}</Text>
        </View>
        <View style={styles.pingDisplay}>
          <Text style={[styles.pingValue, { color: waveColor }]}>{precisionPing.toFixed(1)}</Text>
          <Text style={[styles.pingUnit, { color: colors.mutedForeground }]}>ms</Text>
        </View>
      </View>

      <Animated.View style={{ opacity: fadeAnim }}>
        <Svg width={W} height={H} style={styles.svg}>
          <Defs>
            <LinearGradient id="waveGrad" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={waveColor} stopOpacity="0.35" />
              <Stop offset="1" stopColor={waveColor} stopOpacity="0.02" />
            </LinearGradient>
          </Defs>
          {fill ? <Path d={fill} fill="url(#waveGrad)" /> : null}
          {line ? (
            <Path
              d={line}
              fill="none"
              stroke={waveColor}
              strokeWidth={1.8}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          ) : null}
        </Svg>
      </Animated.View>

      <View style={styles.footer}>
        <MetaItem label="RESPONSE" value={`${responseTime}ms`} color={waveColor} />
        <MetaItem
          label="STABILITY"
          value={stability.toUpperCase()}
          color={waveColor}
        />
        <MetaItem
          label="JITTER"
          value={`±${jitter}ms`}
          color={jitter < 3 ? colors.accent : jitter < 6 ? colors.primary : colors.warning}
        />
        <MetaItem
          label="SAMPLES"
          value={`${pingHistory.length}`}
          color={colors.mutedForeground}
        />
      </View>
    </View>
  );
}

function MetaItem({ label, value, color }: { label: string; value: string; color: string }) {
  const colors = useColors();
  return (
    <View style={metaStyles.item}>
      <Text style={[metaStyles.value, { color }]}>{value}</Text>
      <Text style={[metaStyles.label, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}
const metaStyles = StyleSheet.create({
  item: { alignItems: "center" },
  value: { fontSize: 12, fontWeight: "800", letterSpacing: 0.5 },
  label: { fontSize: 8, letterSpacing: 1.5, textTransform: "uppercase", marginTop: 2 },
});

const styles = StyleSheet.create({
  card: {
    borderRadius: 14,
    borderWidth: 1,
    overflow: "hidden",
    paddingHorizontal: 14,
    paddingBottom: 12,
    paddingTop: 10,
    gap: 8,
  },
  topGlow: { position: "absolute", top: 0, left: 0, right: 0, height: 1.5, opacity: 0.7 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  label: { fontSize: 9, fontWeight: "700", letterSpacing: 2, textTransform: "uppercase" },
  pingDisplay: { flexDirection: "row", alignItems: "baseline", gap: 2 },
  pingValue: { fontSize: 22, fontWeight: "900", letterSpacing: 0.5 },
  pingUnit: { fontSize: 11, fontWeight: "600" },
  svg: { alignSelf: "stretch" },
  footer: { flexDirection: "row", justifyContent: "space-between", paddingTop: 4 },
});
