import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";

type CircularPulseProps = {
  size?: number;
  color?: string;
  label?: string;
};

export default function CircularPulse({
  size = 120,
  color = "#00d4ff",
  label = "SCANNING",
}: CircularPulseProps) {
  const pulse1 = useRef(new Animated.Value(0)).current;
  const pulse2 = useRef(new Animated.Value(0)).current;
  const pulse3 = useRef(new Animated.Value(0)).current;
  const rotate = useRef(new Animated.Value(0)).current;
  const innerRotate = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.timing(rotate, { toValue: 1, duration: 2000, useNativeDriver: true })
    ).start();

    Animated.loop(
      Animated.timing(innerRotate, { toValue: -1, duration: 3000, useNativeDriver: true })
    ).start();

    const pulseOne = () => {
      pulse1.setValue(0);
      Animated.timing(pulse1, { toValue: 1, duration: 1800, useNativeDriver: true }).start(() => pulseOne());
    };
    const pulseTwo = () => {
      pulse2.setValue(0);
      setTimeout(() => {
        Animated.timing(pulse2, { toValue: 1, duration: 1800, useNativeDriver: true }).start(() => pulseTwo());
      }, 600);
    };
    const pulseThree = () => {
      pulse3.setValue(0);
      setTimeout(() => {
        Animated.timing(pulse3, { toValue: 1, duration: 1800, useNativeDriver: true }).start(() => pulseThree());
      }, 1200);
    };

    pulseOne();
    pulseTwo();
    pulseThree();
  }, [pulse1, pulse2, pulse3, rotate, innerRotate]);

  const makePulseStyle = (anim: Animated.Value) => ({
    position: "absolute" as const,
    width: size * 2,
    height: size * 2,
    borderRadius: size,
    borderWidth: 1.5,
    borderColor: color,
    opacity: anim.interpolate({ inputRange: [0, 1], outputRange: [0.8, 0] }),
    transform: [
      {
        scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.6, 2] }),
      },
    ],
  });

  const rotateInterpolate = rotate.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "360deg"],
  });

  const innerRotateInterpolate = innerRotate.interpolate({
    inputRange: [-1, 0],
    outputRange: ["-360deg", "0deg"],
  });

  return (
    <View style={[styles.container, { width: size * 2.2, height: size * 2.2 }]}>
      <Animated.View style={makePulseStyle(pulse1)} />
      <Animated.View style={makePulseStyle(pulse2)} />
      <Animated.View style={makePulseStyle(pulse3)} />

      <Animated.View
        style={[
          styles.outerRing,
          { width: size, height: size, borderRadius: size / 2, borderColor: color },
          { transform: [{ rotate: rotateInterpolate }] },
        ]}
      />
      <Animated.View
        style={[
          styles.innerRing,
          {
            width: size * 0.7,
            height: size * 0.7,
            borderRadius: size * 0.35,
            borderColor: "#8b5cf6",
          },
          { transform: [{ rotate: innerRotateInterpolate }] },
        ]}
      />

      <View style={[styles.core, { width: size * 0.35, height: size * 0.35, borderRadius: size * 0.175, backgroundColor: `${color}22`, borderColor: color }]}>
        <View style={[styles.coreDot, { backgroundColor: color }]} />
      </View>

      <Text style={[styles.label, { color, fontSize: size * 0.12, marginTop: size * 1.15 }]}>
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
  outerRing: {
    position: "absolute",
    borderWidth: 2,
    borderStyle: "dashed",
    opacity: 0.8,
  },
  innerRing: {
    position: "absolute",
    borderWidth: 1.5,
    borderStyle: "dotted",
    opacity: 0.6,
  },
  core: {
    position: "absolute",
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  coreDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  label: {
    position: "absolute",
    fontWeight: "700",
    letterSpacing: 3,
    textShadowColor: "#00d4ff",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 8,
  },
});
