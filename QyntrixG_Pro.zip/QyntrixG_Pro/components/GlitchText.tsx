import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";

const BLUE = "#00d4ff";
const VIOLET = "#8b5cf6";
const WHITE = "#e8f4ff";

type GlitchTextProps = {
  text: string;
  fontSize?: number;
  fontFamily?: string;
};

export default function GlitchText({ text, fontSize = 42, fontFamily }: GlitchTextProps) {
  const colorAnim = useRef(new Animated.Value(0)).current;
  const glitchX1 = useRef(new Animated.Value(0)).current;
  const glitchX2 = useRef(new Animated.Value(0)).current;
  const glitchOpacity1 = useRef(new Animated.Value(0)).current;
  const glitchOpacity2 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(colorAnim, { toValue: 1, duration: 800, useNativeDriver: false }),
        Animated.timing(colorAnim, { toValue: 0.5, duration: 600, useNativeDriver: false }),
        Animated.timing(colorAnim, { toValue: 0, duration: 800, useNativeDriver: false }),
      ])
    ).start();

    const glitchLoop = () => {
      const delay = Math.random() * 1200 + 200;
      setTimeout(() => {
        Animated.sequence([
          Animated.parallel([
            Animated.timing(glitchOpacity1, { toValue: 0.7, duration: 50, useNativeDriver: true }),
            Animated.timing(glitchX1, {
              toValue: Math.random() * 8 - 4,
              duration: 50,
              useNativeDriver: true,
            }),
          ]),
          Animated.parallel([
            Animated.timing(glitchOpacity2, { toValue: 0.5, duration: 50, useNativeDriver: true }),
            Animated.timing(glitchX2, {
              toValue: Math.random() * -8 + 4,
              duration: 50,
              useNativeDriver: true,
            }),
          ]),
          Animated.parallel([
            Animated.timing(glitchOpacity1, { toValue: 0, duration: 80, useNativeDriver: true }),
            Animated.timing(glitchOpacity2, { toValue: 0, duration: 80, useNativeDriver: true }),
            Animated.timing(glitchX1, { toValue: 0, duration: 80, useNativeDriver: true }),
            Animated.timing(glitchX2, { toValue: 0, duration: 80, useNativeDriver: true }),
          ]),
        ]).start(() => glitchLoop());
      }, delay);
    };

    glitchLoop();
  }, [colorAnim, glitchX1, glitchX2, glitchOpacity1, glitchOpacity2]);

  const color = colorAnim.interpolate({
    inputRange: [0, 0.5, 1],
    outputRange: [BLUE, WHITE, VIOLET],
  });

  const textStyle = {
    fontSize,
    fontFamily,
    letterSpacing: fontSize * 0.08,
    textTransform: "uppercase" as const,
  };

  return (
    <View style={styles.container}>
      <Animated.Text style={[styles.glitch1, textStyle, { transform: [{ translateX: glitchX1 }], opacity: glitchOpacity1, color: BLUE }]}>
        {text}
      </Animated.Text>
      <Animated.Text style={[styles.glitch2, textStyle, { transform: [{ translateX: glitchX2 }], opacity: glitchOpacity2, color: VIOLET }]}>
        {text}
      </Animated.Text>
      <Animated.Text style={[styles.main, textStyle, { color }]}>{text}</Animated.Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
  main: {
    fontWeight: "900",
    textShadowColor: "#00d4ff",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },
  glitch1: {
    position: "absolute",
    fontWeight: "900",
  },
  glitch2: {
    position: "absolute",
    fontWeight: "900",
  },
});
