import { MaterialCommunityIcons } from "@expo/vector-icons";
import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

type ChannelInfo = {
  type: "wifi" | "mobile";
  signal: number;
  speed: number;
  label: string;
};

type DualChannelCardProps = {
  enabled: boolean;
  wifiSpeed: number;
  mobileSpeed: number;
  combinedThroughput: number;
};

function SignalBars({ signal, color }: { signal: number; color: string }) {
  const bars = 4;
  const filled = Math.ceil((signal / 100) * bars);
  return (
    <View style={{ flexDirection: "row", alignItems: "flex-end", gap: 2 }}>
      {Array.from({ length: bars }, (_, i) => (
        <View
          key={i}
          style={{
            width: 4,
            height: 4 + i * 3,
            borderRadius: 1,
            backgroundColor: i < filled ? color : `${color}30`,
          }}
        />
      ))}
    </View>
  );
}

function ChannelBlock({ info, active }: { info: ChannelInfo; active: boolean }) {
  const colors = useColors();
  const color = info.type === "wifi" ? colors.primary : colors.secondary;
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (active) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, { toValue: 1.08, duration: 800, useNativeDriver: true }),
          Animated.timing(pulse, { toValue: 1, duration: 800, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulse.setValue(1);
    }
  }, [active, pulse]);

  return (
    <Animated.View
      style={[
        channelStyles.block,
        {
          backgroundColor: active ? `${color}12` : `${color}06`,
          borderColor: active ? `${color}55` : `${color}22`,
          transform: [{ scale: pulse }],
        },
      ]}
    >
      <View style={channelStyles.top}>
        <MaterialCommunityIcons
          name={info.type === "wifi" ? "wifi" : "signal"}
          size={18}
          color={active ? color : `${color}60`}
        />
        <SignalBars signal={info.signal} color={active ? color : `${color}60`} />
      </View>
      <Text style={[channelStyles.speed, { color: active ? color : `${color}80` }]}>
        {info.speed.toFixed(0)}
        <Text style={{ fontSize: 9 }}> Mbps</Text>
      </Text>
      <Text style={[channelStyles.label, { color: colors.mutedForeground }]}>{info.label}</Text>
    </Animated.View>
  );
}

const channelStyles = StyleSheet.create({
  block: { flex: 1, borderRadius: 10, borderWidth: 1, padding: 10, gap: 4 },
  top: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  speed: { fontSize: 18, fontWeight: "800" },
  label: { fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase" },
});

function DataFlow({ enabled }: { enabled: boolean }) {
  const colors = useColors();
  const flowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (enabled) {
      Animated.loop(
        Animated.timing(flowAnim, { toValue: 1, duration: 1200, useNativeDriver: false })
      ).start();
    } else {
      flowAnim.setValue(0);
    }
  }, [enabled, flowAnim]);

  const left = flowAnim.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });

  return (
    <View style={flowStyles.track}>
      {enabled ? (
        <Animated.View style={[flowStyles.dot, { left, backgroundColor: colors.accent }]} />
      ) : (
        <View style={[flowStyles.dormant, { backgroundColor: colors.border }]} />
      )}
    </View>
  );
}

const flowStyles = StyleSheet.create({
  track: { height: 2, backgroundColor: "#1a2f50", borderRadius: 1, overflow: "hidden", position: "relative" },
  dot: { position: "absolute", width: 20, height: "100%", borderRadius: 1, shadowColor: "#00ff88", shadowOffset: { width: 0, height: 0 }, shadowRadius: 4, shadowOpacity: 1 },
  dormant: { flex: 1, height: "100%" },
});

export default function DualChannelCard({ enabled, wifiSpeed, mobileSpeed, combinedThroughput }: DualChannelCardProps) {
  const colors = useColors();

  const wifi: ChannelInfo = { type: "wifi", signal: 78, speed: wifiSpeed, label: "Wi-Fi Channel" };
  const mobile: ChannelInfo = { type: "mobile", signal: 62, speed: mobileSpeed, label: "Mobile Channel" };

  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: enabled ? `${colors.accent}30` : colors.border }]}>
      <View style={[styles.topBar, { backgroundColor: enabled ? colors.accent : colors.border }]} />

      <View style={styles.header}>
        <MaterialCommunityIcons
          name="bridge"
          size={16}
          color={enabled ? colors.accent : colors.mutedForeground}
        />
        <Text style={[styles.title, { color: enabled ? colors.accent : colors.mutedForeground }]}>
          DUAL-CHANNEL BRIDGE
        </Text>
        <View style={[styles.statusBadge, { backgroundColor: enabled ? `${colors.accent}18` : `${colors.border}`, borderColor: enabled ? `${colors.accent}50` : colors.border }]}>
          <Text style={[styles.statusText, { color: enabled ? colors.accent : colors.mutedForeground }]}>
            {enabled ? "ACTIVE" : "STANDBY"}
          </Text>
        </View>
      </View>

      <View style={styles.channels}>
        <ChannelBlock info={wifi} active={enabled} />
        <View style={styles.bridgeCol}>
          <MaterialCommunityIcons name="arrow-left-right" size={14} color={enabled ? colors.accent : colors.mutedForeground} />
          <DataFlow enabled={enabled} />
        </View>
        <ChannelBlock info={mobile} active={enabled} />
      </View>

      {enabled && (
        <View style={[styles.throughput, { borderTopColor: colors.border }]}>
          <Text style={[styles.throughputLabel, { color: colors.mutedForeground }]}>COMBINED THROUGHPUT</Text>
          <Text style={[styles.throughputValue, { color: colors.accent }]}>{combinedThroughput.toFixed(1)} Mbps</Text>
          <Text style={[styles.mpTcp, { color: `${colors.accent}80` }]}>Multipath TCP Bridge</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 14, borderWidth: 1, overflow: "hidden" },
  topBar: { height: 1.5, opacity: 0.7 },
  header: { flexDirection: "row", alignItems: "center", gap: 8, padding: 12, paddingBottom: 8 },
  title: { flex: 1, fontSize: 10, fontWeight: "700", letterSpacing: 2 },
  statusBadge: { borderWidth: 1, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  statusText: { fontSize: 8, fontWeight: "700", letterSpacing: 1.5 },
  channels: { flexDirection: "row", gap: 8, padding: 12, paddingTop: 4 },
  bridgeCol: { alignItems: "center", justifyContent: "center", gap: 6, width: 28 },
  throughput: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 8, borderTopWidth: 1, gap: 8 },
  throughputLabel: { fontSize: 8, letterSpacing: 1.5, fontWeight: "600" },
  throughputValue: { flex: 1, fontSize: 15, fontWeight: "800", textAlign: "center" },
  mpTcp: { fontSize: 8, letterSpacing: 1 },
});
